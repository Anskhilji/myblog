-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 27, 2021 at 02:45 AM
-- Server version: 5.6.49-cll-lve
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dgaps_ans_blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE `authors` (
  `id` int(11) UNSIGNED NOT NULL,
  `status` int(11) NOT NULL DEFAULT '2',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `meta_tags` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_schema` text COLLATE utf8mb4_unicode_ci,
  `detail` text COLLATE utf8mb4_unicode_ci,
  `cover_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `posts` int(11) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`id`, `status`, `name`, `slug`, `meta_title`, `meta_description`, `meta_tags`, `author_schema`, `detail`, `cover_image`, `og_image`, `posts`, `created_at`, `updated_at`) VALUES
(1, 1, 'Anskhan', 'anskhan', 'Anskhan | Informative blog', 'Proin eget tortor risus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula.', 'test,eng,blog,article', '[\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\/\\\",\\r\\n  \\\"@type\\\": \\\"Person\\\",\\r\\n  \\\"name\\\": \\\"\\\",\\r\\n  \\\"url\\\": \\\"\\\",\\r\\n  \\\"image\\\": \\\"\\\"  \\r\\n}\\r\\n<\\/script>\",\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\/\\\",\\r\\n  \\\"@type\\\": \\\"Person\\\",\\r\\n  \\\"name\\\": \\\"\\\",\\r\\n  \\\"url\\\": \\\"\\\",\\r\\n  \\\"image\\\": \\\"\\\"  \\r\\n}\\r\\n<\\/script>\"]', '<p>Web Developer at Digital Applications.</p>', 'http://ans-blog.unifyp.com/images/capture-224x281.png', 'http://ans-blog.unifyp.com/images/mother-son-embracing-outdoors-on-600w-746201944-370x259.webp', 0, '2021-04-06 12:11:39', '2021-04-27 15:50:18'),
(8, 2, 'Imran', 'imran', 'Imran | Tech Article', 'test', 'imran', '[null]', '<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Nulla porttitor accumsan tincidunt. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.</p>', 'http://ans-blog.unifyp.com/images/capture-224x281.png', 'http://ans-blog.unifyp.com/images/2-370x208.jpg', 0, '2021-04-07 09:40:07', '2021-04-27 15:50:47');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) UNSIGNED NOT NULL,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `meta_tags` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_schema` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `slug`, `meta_title`, `meta_description`, `meta_tags`, `category_schema`, `created_at`, `updated_at`) VALUES
(1, 'General', 'general', 'General', 'This description is for general', 'general', '[\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\\",\\r\\n  \\\"@type\\\": \\\"Article\\\",\\r\\n  \\\"mainEntityOfPage\\\": {\\r\\n    \\\"@type\\\": \\\"WebPage\\\",\\r\\n    \\\"@id\\\": \\\"http:\\/\\/blog.dgp\\/technology\\\"\\r\\n  },\\r\\n  \\\"headline\\\": \\\"Technology\\\",\\r\\n  \\\"image\\\": \\\"\\\",  \\r\\n  \\\"author\\\": {\\r\\n    \\\"@type\\\": \\\"\\\",\\r\\n    \\\"name\\\": \\\"\\\"\\r\\n  },  \\r\\n  \\\"publisher\\\": {\\r\\n    \\\"@type\\\": \\\"Organization\\\",\\r\\n    \\\"name\\\": \\\"\\\",\\r\\n    \\\"logo\\\": {\\r\\n      \\\"@type\\\": \\\"ImageObject\\\",\\r\\n      \\\"url\\\": \\\"\\\"\\r\\n    }\\r\\n  },\\r\\n  \\\"datePublished\\\": \\\"\\\"\\r\\n}\\r\\n<\\/script>\"]', '2021-03-23 08:05:22', '2021-03-23 08:05:22'),
(8, 'Technology', 'technology', 'Technology', 'This description is for technology', 'tech,technology', '[\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\\",\\r\\n  \\\"@type\\\": \\\"Article\\\",\\r\\n  \\\"mainEntityOfPage\\\": {\\r\\n    \\\"@type\\\": \\\"WebPage\\\",\\r\\n    \\\"@id\\\": \\\"http:\\/\\/blog.dgp\\/technology\\\"\\r\\n  },\\r\\n  \\\"headline\\\": \\\"Technology\\\",\\r\\n  \\\"image\\\": \\\"\\\",  \\r\\n  \\\"author\\\": {\\r\\n    \\\"@type\\\": \\\"\\\",\\r\\n    \\\"name\\\": \\\"\\\"\\r\\n  },  \\r\\n  \\\"publisher\\\": {\\r\\n    \\\"@type\\\": \\\"Organization\\\",\\r\\n    \\\"name\\\": \\\"\\\",\\r\\n    \\\"logo\\\": {\\r\\n      \\\"@type\\\": \\\"ImageObject\\\",\\r\\n      \\\"url\\\": \\\"\\\"\\r\\n    }\\r\\n  },\\r\\n  \\\"datePublished\\\": \\\"\\\"\\r\\n}\\r\\n<\\/script>\"]', '2021-03-23 08:05:22', '2021-03-23 08:05:22'),
(9, 'Bollywood', 'bollywood', 'Bollywood news', 'Description about bollywood news', 'bollywood,news', '[\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\\",\\r\\n  \\\"@type\\\": \\\"Article\\\",\\r\\n  \\\"mainEntityOfPage\\\": {\\r\\n    \\\"@type\\\": \\\"WebPage\\\",\\r\\n    \\\"@id\\\": \\\"http:\\/\\/blog.dgp\\/technology\\\"\\r\\n  },\\r\\n  \\\"headline\\\": \\\"Technology\\\",\\r\\n  \\\"image\\\": \\\"\\\",  \\r\\n  \\\"author\\\": {\\r\\n    \\\"@type\\\": \\\"\\\",\\r\\n    \\\"name\\\": \\\"\\\"\\r\\n  },  \\r\\n  \\\"publisher\\\": {\\r\\n    \\\"@type\\\": \\\"Organization\\\",\\r\\n    \\\"name\\\": \\\"\\\",\\r\\n    \\\"logo\\\": {\\r\\n      \\\"@type\\\": \\\"ImageObject\\\",\\r\\n      \\\"url\\\": \\\"\\\"\\r\\n    }\\r\\n  },\\r\\n  \\\"datePublished\\\": \\\"\\\"\\r\\n}\\r\\n<\\/script>\",\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\\",\\r\\n  \\\"@type\\\": \\\"Article\\\",\\r\\n  \\\"mainEntityOfPage\\\": {\\r\\n    \\\"@type\\\": \\\"WebPage\\\",\\r\\n    \\\"@id\\\": \\\"http:\\/\\/blog.dgp\\/technology\\\"\\r\\n  },\\r\\n  \\\"headline\\\": \\\"Technology\\\",\\r\\n  \\\"image\\\": \\\"\\\",  \\r\\n  \\\"author\\\": {\\r\\n    \\\"@type\\\": \\\"\\\",\\r\\n    \\\"name\\\": \\\"\\\"\\r\\n  },  \\r\\n  \\\"publisher\\\": {\\r\\n    \\\"@type\\\": \\\"Organization\\\",\\r\\n    \\\"name\\\": \\\"\\\",\\r\\n    \\\"logo\\\": {\\r\\n      \\\"@type\\\": \\\"ImageObject\\\",\\r\\n      \\\"url\\\": \\\"\\\"\\r\\n    }\\r\\n  },\\r\\n  \\\"datePublished\\\": \\\"\\\"\\r\\n}\\r\\n<\\/script>\"]', '2021-03-23 08:06:34', '2021-03-23 08:06:34'),
(10, 'Programming', 'programming', 'Programming', 'Decsription about laravel 8 blog', 'blog,programmers,programming', '[\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\\",\\r\\n  \\\"@type\\\": \\\"Article\\\",\\r\\n  \\\"mainEntityOfPage\\\": {\\r\\n    \\\"@type\\\": \\\"WebPage\\\",\\r\\n    \\\"@id\\\": \\\"http:\\/\\/blog.dgp\\/technology\\\"\\r\\n  },\\r\\n  \\\"headline\\\": \\\"Technology\\\",\\r\\n  \\\"image\\\": \\\"\\\",  \\r\\n  \\\"author\\\": {\\r\\n    \\\"@type\\\": \\\"\\\",\\r\\n    \\\"name\\\": \\\"\\\"\\r\\n  },  \\r\\n  \\\"publisher\\\": {\\r\\n    \\\"@type\\\": \\\"Organization\\\",\\r\\n    \\\"name\\\": \\\"\\\",\\r\\n    \\\"logo\\\": {\\r\\n      \\\"@type\\\": \\\"ImageObject\\\",\\r\\n      \\\"url\\\": \\\"\\\"\\r\\n    }\\r\\n  },\\r\\n  \\\"datePublished\\\": \\\"\\\"\\r\\n}\\r\\n<\\/script>\"]', '2021-03-23 08:31:54', '2021-03-23 08:33:17');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` int(11) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` int(11) UNSIGNED NOT NULL,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ans` text COLLATE utf8mb4_unicode_ci,
  `order` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `question`, `ans`, `order`, `created_at`, `updated_at`) VALUES
(7, 'Voluptas velit earum', '<p>Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Vivamus suscipit tortor eget felis porttitor volutpat. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Cras ultricies ligula sed magna dictum porta. Cras ultricies ligula sed magna dictum porta. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla porttitor accumsan tincidunt. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla quis lorem ut libero malesuada feugiat. Cras ultricies ligula sed magna dictum porta. Donec rutrum congue leo eget malesuada. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Sed porttitor lectus nibh. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Donec rutrum congue leo eget malesuada. Pellentesque in ipsum id orci porta dapibus. Quisque velit nisi, pretium ut lacinia in, elementum id enim.</p>', 2, '2021-04-05 14:20:54', '2021-04-09 10:10:59'),
(8, 'Sint ipsum qui moll', '<p>Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Vivamus suscipit tortor eget felis porttitor volutpat. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Cras ultricies ligula sed magna dictum porta. Cras ultricies ligula sed magna dictum porta. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla porttitor accumsan tincidunt. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla quis lorem ut libero malesuada feugiat. Cras ultricies ligula sed magna dictum porta. Donec rutrum congue leo eget malesuada. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Sed porttitor lectus nibh. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Donec rutrum congue leo eget malesuada. Pellentesque in ipsum id orci porta dapibus. Quisque velit nisi, pretium ut lacinia in, elementum id enim.</p>', 0, '2021-04-05 14:21:00', '2021-04-05 14:32:03'),
(9, 'Deleniti omnis archi', '<p>Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Vivamus suscipit tortor eget felis porttitor volutpat. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Cras ultricies ligula sed magna dictum porta. Cras ultricies ligula sed magna dictum porta. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla porttitor accumsan tincidunt. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla quis lorem ut libero malesuada feugiat. Cras ultricies ligula sed magna dictum porta. Donec rutrum congue leo eget malesuada. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Sed porttitor lectus nibh. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Donec rutrum congue leo eget malesuada. Pellentesque in ipsum id orci porta dapibus. Quisque velit nisi, pretium ut lacinia in, elementum id enim.</p>', 1, '2021-04-05 14:21:06', '2021-04-09 10:10:59');

-- --------------------------------------------------------

--
-- Table structure for table `homes`
--

CREATE TABLE `homes` (
  `id` int(11) UNSIGNED NOT NULL,
  `page_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_tags` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home_schema` text COLLATE utf8mb4_unicode_ci,
  `og_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `detail` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `homes`
--

INSERT INTO `homes` (`id`, `page_title`, `meta_title`, `meta_description`, `meta_tags`, `home_schema`, `og_image`, `detail`, `created_at`, `updated_at`) VALUES
(2, 'contact-us', 'Contact us', 'this description is just for testing purpose', 'contact,contactus,important', '[\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\/\\\",\\r\\n  \\\"@type\\\": \\\"WebSite\\\",\\r\\n  \\\"name\\\": \\\"\\\",\\r\\n  \\\"url\\\": \\\"\\\",\\r\\n  \\\"potentialAction\\\": {\\r\\n    \\\"@type\\\": \\\"SearchAction\\\",\\r\\n    \\\"target\\\": \\\"{search_term_string}\\\",\\r\\n    \\\"query-input\\\": \\\"required name=search_term_string\\\"\\r\\n  }\\r\\n}\\r\\n<\\/script>\",\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\/\\\",\\r\\n  \\\"@type\\\": \\\"WebSite\\\",\\r\\n  \\\"name\\\": \\\"\\\",\\r\\n  \\\"url\\\": \\\"\\\",\\r\\n  \\\"potentialAction\\\": {\\r\\n    \\\"@type\\\": \\\"SearchAction\\\",\\r\\n    \\\"target\\\": \\\"{search_term_string}\\\",\\r\\n    \\\"query-input\\\": \\\"required name=search_term_string\\\"\\r\\n  }\\r\\n}\\r\\n<\\/script>\"]', 'http://blog.dgp/images/2-370x208.jpg', NULL, NULL, '2021-04-05 08:32:04'),
(3, 'privacy-policy', 'Privacy Policy | My Blog', 'This description is about the Privacy Policy of My Blog Website...', 'privacy,policy,privacy policy,myblog', '[\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\/\\\",\\r\\n  \\\"@type\\\": \\\"Person\\\",\\r\\n  \\\"name\\\": \\\"\\\",\\r\\n  \\\"url\\\": \\\"\\\",\\r\\n  \\\"image\\\": \\\"\\\"  \\r\\n}\\r\\n<\\/script>\",\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\/\\\",\\r\\n  \\\"@type\\\": \\\"Person\\\",\\r\\n  \\\"name\\\": \\\"\\\",\\r\\n  \\\"url\\\": \\\"\\\",\\r\\n  \\\"image\\\": \\\"\\\"  \\r\\n}\\r\\n<\\/script>\"]', 'http://ans-blog.unifyp.com/images/social-media.jpg', '<h1>Privacy Policy</h1>\r\n<p>Curabitur aliquet quam id dui posuere blandit. Curabitur aliquet quam id dui posuere blandit. Donec sollicitudin molestie malesuada. Donec rutrum congue leo eget malesuada. Donec rutrum congue leo eget malesuada. Cras ultricies ligula sed magna dictum porta. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Curabitur aliquet quam id dui posuere blandit. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Proin eget tortor risus. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Pellentesque in ipsum id orci porta dapibus. Donec rutrum congue leo eget malesuada. Donec sollicitudin molestie malesuada. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.</p>\r\n<p>Curabitur aliquet quam id dui posuere blandit. Curabitur aliquet quam id dui posuere blandit. Donec sollicitudin molestie malesuada. Donec rutrum congue leo eget malesuada. Donec rutrum congue leo eget malesuada. Cras ultricies ligula sed magna dictum porta. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Curabitur aliquet quam id dui posuere blandit. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Proin eget tortor risus. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Pellentesque in ipsum id orci porta dapibus. Donec rutrum congue leo eget malesuada. Donec sollicitudin molestie malesuada. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.</p>', NULL, '2021-04-28 10:52:05'),
(4, 'terms-condition', 'Terms & Conditions | My Blog', 'This description is related to company terms & condition...', 'terms,condition,terms&condition', '[\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\\",\\r\\n  \\\"@type\\\": \\\"Organization\\\",\\r\\n  \\\"name\\\": \\\"\\\",\\r\\n  \\\"url\\\": \\\"\\\",\\r\\n  \\\"logo\\\": \\\"\\\"\\r\\n}\\r\\n<\\/script>\",\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\\",\\r\\n  \\\"@type\\\": \\\"Organization\\\",\\r\\n  \\\"name\\\": \\\"\\\",\\r\\n  \\\"url\\\": \\\"\\\",\\r\\n  \\\"logo\\\": \\\"\\\"\\r\\n}\\r\\n<\\/script>\"]', 'http://ans-blog.unifyp.com/images/make-quick-money-as-a-freelance-writer-200x131.jpg', '<p>Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Donec sollicitudin molestie malesuada. Curabitur aliquet quam id dui posuere blandit. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Curabitur aliquet quam id dui posuere blandit. Proin eget tortor risus. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Nulla porttitor accumsan tincidunt. Vivamus suscipit tortor eget felis porttitor volutpat.</p>\r\n<p><img title=\"2\" src=\"http://blog.dgp/images/2-370x208.jpg\" alt=\"2\" width=\"751\" height=\"422\" /></p>\r\n<p>Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Donec sollicitudin molestie malesuada. Curabitur aliquet quam id dui posuere blandit. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Curabitur aliquet quam id dui posuere blandit. Proin eget tortor risus. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Nulla porttitor accumsan tincidunt. Vivamus suscipit tortor eget felis porttitor volutpat.</p>\r\n<p>Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Donec sollicitudin molestie malesuada. Curabitur aliquet quam id dui posuere blandit. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Curabitur aliquet quam id dui posuere blandit. Proin eget tortor risus. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Nulla porttitor accumsan tincidunt. Vivamus suscipit tortor eget felis porttitor volutpat.</p>', NULL, '2021-04-28 10:56:51'),
(7, 'home', 'My Blog | Informative blog', 'Home page meta description ...:)', 'info,tech', '[\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\/\\\",\\r\\n  \\\"@type\\\": \\\"WebSite\\\",\\r\\n  \\\"name\\\": \\\"\\\",\\r\\n  \\\"url\\\": \\\"\\\",\\r\\n  \\\"potentialAction\\\": {\\r\\n    \\\"@type\\\": \\\"SearchAction\\\",\\r\\n    \\\"target\\\": \\\"{search_term_string}\\\",\\r\\n    \\\"query-input\\\": \\\"required name=search_term_string\\\"\\r\\n  }\\r\\n}\\r\\n<\\/script>\"]', 'http://blog.dgp/images/2-370x208.jpg', NULL, '2021-04-05 07:28:58', '2021-04-05 08:44:38'),
(9, 'faqs', 'Faqs | Questions & Answer', 'this description is about faqs...', 'faqs,ans,question,test', '[\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\\",\\r\\n  \\\"@type\\\": \\\"FAQPage\\\",\\r\\n  \\\"mainEntity\\\": {\\r\\n    \\\"@type\\\": \\\"Question\\\",\\r\\n    \\\"name\\\": \\\"\\\",\\r\\n    \\\"acceptedAnswer\\\": {\\r\\n      \\\"@type\\\": \\\"Answer\\\",\\r\\n      \\\"text\\\": \\\"\\\"\\r\\n    }\\r\\n  }\\r\\n}\\r\\n<\\/script>\",\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\\",\\r\\n  \\\"@type\\\": \\\"FAQPage\\\",\\r\\n  \\\"mainEntity\\\": {\\r\\n    \\\"@type\\\": \\\"Question\\\",\\r\\n    \\\"name\\\": \\\"\\\",\\r\\n    \\\"acceptedAnswer\\\": {\\r\\n      \\\"@type\\\": \\\"Answer\\\",\\r\\n      \\\"text\\\": \\\"\\\"\\r\\n    }\\r\\n  }\\r\\n}\\r\\n<\\/script>\"]', 'http://ans-blog.unifyp.com/images/mother-son-embracing-outdoors-on-600w-746201944-370x259.webp', NULL, '2021-04-05 13:47:03', '2021-04-28 10:56:33');

-- --------------------------------------------------------

--
-- Table structure for table `internallinks`
--

CREATE TABLE `internallinks` (
  `id` int(11) UNSIGNED NOT NULL,
  `target` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `types_of_links` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `max_links_in_one_article` int(11) DEFAULT NULL,
  `fixed_percent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `max_links_limit` int(11) DEFAULT NULL,
  `max_links_on_same_anchor_text` int(11) DEFAULT NULL,
  `max_links_on_different_anchor_text` int(11) DEFAULT NULL,
  `max_links_on_its_own_article` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `internallinks`
--

INSERT INTO `internallinks` (`id`, `target`, `types_of_links`, `max_links_in_one_article`, `fixed_percent`, `max_links_limit`, `max_links_on_same_anchor_text`, `max_links_on_different_anchor_text`, `max_links_on_its_own_article`, `created_at`, `updated_at`) VALUES
(1, '_self', NULL, 3, 'fixed', 5, 6, 8, 9, '2021-04-23 14:12:29', '2021-04-23 14:22:53');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alt` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `caption` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `images` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sizes` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `folder` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `title`, `alt`, `caption`, `description`, `images`, `sizes`, `type`, `folder`, `created_at`, `updated_at`) VALUES
(4, '2', '2', '2', '2', '{\"full\":\"2.jpg\",\"370\":\"2-370x208.jpg\"}', '[\"370\"]', 'jpg', '1', '2021-03-31 13:52:39', NULL),
(6, 'LOG-POINT', 'LOG-POINT', 'LOG-POINT', 'LOG-POINT', '{\"full\":\"log-point.png\"}', '[]', 'png', '2', '2021-04-03 13:32:01', NULL),
(7, 'favicon', 'favicon', 'favicon', 'favicon', '{\"full\":\"favicon.png\"}', '[]', 'png', '2', '2021-04-03 13:32:45', NULL),
(8, 'mother-son-embracing-outdoors-on-600w-746201944', 'mother-son-embracing-outdoors-on-600w-746201944', 'mother-son-embracing-outdoors-on-600w-746201944', 'mother-son-embracing-outdoors-on-600w-746201944', '{\"full\":\"mother-son-embracing-outdoors-on-600w-746201944.webp\",\"370\":\"mother-son-embracing-outdoors-on-600w-746201944-370x259.webp\"}', '[\"370\"]', 'webp', '2', '2021-04-03 13:35:18', NULL),
(9, 'future-drones-1', 'future-drones-1', 'future-drones-1', 'future-drones-1', '{\"full\":\"future-drones-1-1.jpg\"}', '[]', 'jpg', '1', '2021-04-24 17:00:55', NULL),
(10, 'fruits-benefits-1-1', 'fruits-benefits-1-1', 'fruits-benefits-1-1', 'fruits-benefits-1-1', '{\"full\":\"fruits-benefits-1-1.jpg\"}', '[]', 'jpg', '1', '2021-04-24 17:05:39', NULL),
(11, 'social-media', 'social-media', 'social-media', 'social-media', '{\"full\":\"social-media.jpg\"}', '[]', 'jpg', '1', '2021-04-24 17:09:22', NULL),
(12, 'sports-outside', 'sports-outside', 'sports-outside', 'sports-outside', '{\"full\":\"sports-outside-1.jpg\"}', '[]', 'jpg', '1', '2021-04-24 17:14:06', NULL),
(13, 'a-sight-on-spiritual-dimension', 'a-sight-on-spiritual-dimension', 'a-sight-on-spiritual-dimension', 'a-sight-on-spiritual-dimension', '{\"full\":\"a-sight-on-spiritual-dimension.jpg\"}', '[]', 'jpg', '1', '2021-04-24 17:48:42', NULL),
(14, 'make-quick-money-as-a-freelance-writer-200x131', 'make-quick-money-as-a-freelance-writer-200x131', 'make-quick-money-as-a-freelance-writer-200x131', 'make-quick-money-as-a-freelance-writer-200x131', '{\"full\":\"make-quick-money-as-a-freelance-writer-200x131.jpg\"}', '[]', 'jpg', '1', '2021-04-24 17:53:03', NULL),
(15, 'social-media-influencers', 'social-media-influencers', 'social-media-influencers', 'social-media-influencers', '{\"full\":\"social-media-influencers.jpg\"}', '[\"28\",\"28\"]', 'jpg', '1', '2021-04-24 18:02:20', '2021-04-26 14:09:45'),
(16, 'Capture', 'Capture', 'Capture', 'Capture', '{\"full\":\"capture.png\",\"224\":\"capture-224x281.png\"}', '[\"224\"]', 'PNG', '1', '2021-04-27 15:47:38', '2021-04-27 15:50:15');

-- --------------------------------------------------------

--
-- Table structure for table `media_category`
--

CREATE TABLE `media_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `folder_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `folder_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `media_category`
--

INSERT INTO `media_category` (`id`, `folder_type`, `folder_name`, `created_at`, `updated_at`) VALUES
(1, 'folder', 'posts', NULL, NULL),
(2, 'folder', 'logo', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `media_setting`
--

CREATE TABLE `media_setting` (
  `id` int(10) UNSIGNED NOT NULL,
  `media_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `media_value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `auto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `media_setting`
--

INSERT INTO `media_setting` (`id`, `media_key`, `media_value`, `auto`, `created_at`, `updated_at`) VALUES
(1, 'sizes', '[\"370\"]', '', NULL, NULL),
(2, 'auto_webp', '0', '', NULL, NULL),
(3, 'default_title', '1', '', NULL, NULL),
(4, 'default_alt_text', '1', '', NULL, NULL),
(5, 'default_desp', '1', '', NULL, NULL),
(6, 'default_caption', '1', '', NULL, NULL),
(7, 'default_image_size', '370', '', NULL, NULL),
(8, 'default_image_type', '0', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_03_08_083827_create_categories_table', 2),
(5, '2021_03_08_094825_create_posts_table', 3),
(9, '2021_03_15_071001_remove_category_id_from_posts', 4),
(24, '2020_05_29_160923_create_media_table', 5),
(25, '2020_05_29_160951_create_media_folder_table', 5),
(26, '2020_06_01_064731_create_media_setting_table', 5),
(27, '2021_03_15_074411_create_posts_table', 5),
(28, '2021_03_20_094851_create_subscribers_table', 6),
(29, '2021_03_25_070710_create_settings_table', 7),
(30, '2021_04_02_052022_create_menus_table', 8),
(31, '2021_04_02_125403_create_homes_table', 8),
(33, '2021_04_05_074506_create-faqs-table', 9),
(34, '2021_04_05_132248_create_authors_table', 10),
(35, '2021_04_23_083806_create_table_internallinks', 11);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) UNSIGNED NOT NULL,
  `category_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author_id` int(11) DEFAULT NULL,
  `post_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `meta_tags` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post_schema` text COLLATE utf8mb4_unicode_ci,
  `green_text` text COLLATE utf8mb4_unicode_ci,
  `red_text` text COLLATE utf8mb4_unicode_ci,
  `black_text` text COLLATE utf8mb4_unicode_ci,
  `faqs` text COLLATE utf8mb4_unicode_ci,
  `internal_tags` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post_detail` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_cover_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post_og_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `post_view` int(255) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `category_id`, `author_id`, `post_title`, `slug`, `meta_title`, `meta_description`, `meta_tags`, `post_schema`, `green_text`, `red_text`, `black_text`, `faqs`, `internal_tags`, `post_detail`, `post_cover_image`, `post_og_image`, `post_status`, `post_view`, `created_at`, `updated_at`) VALUES
(20, '1', 1, 'Health Benefits And Disadvantages Of Fruits', 'health-benefits-and-disadvantages-of-fruits', 'Health Benefits And Disadvantages Of Fruits', 'Food is one of the basic needs of the human body to stay alive. Fruits are vital part of food that provides vitamins, potassium and other minerals to our body.', 'fruit,fruits,health', '[\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\\",\\r\\n  \\\"@type\\\": \\\"Article\\\",\\r\\n  \\\"headline\\\": \\\"\\\",\\r\\n  \\\"image\\\": \\\"\\\",  \\r\\n  \\\"author\\\": {\\r\\n    \\\"@type\\\": \\\"\\\",\\r\\n    \\\"name\\\": \\\"\\\"\\r\\n  },  \\r\\n  \\\"publisher\\\": {\\r\\n    \\\"@type\\\": \\\"Organization\\\",\\r\\n    \\\"name\\\": \\\"\\\",\\r\\n    \\\"logo\\\": {\\r\\n      \\\"@type\\\": \\\"ImageObject\\\",\\r\\n      \\\"url\\\": \\\"\\\"\\r\\n    }\\r\\n  },\\r\\n  \\\"datePublished\\\": \\\"\\\"\\r\\n}\\r\\n<\\/script>\",\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\\",\\r\\n  \\\"@type\\\": \\\"Article\\\",\\r\\n  \\\"headline\\\": \\\"\\\",\\r\\n  \\\"image\\\": \\\"\\\",  \\r\\n  \\\"author\\\": {\\r\\n    \\\"@type\\\": \\\"\\\",\\r\\n    \\\"name\\\": \\\"\\\"\\r\\n  },  \\r\\n  \\\"publisher\\\": {\\r\\n    \\\"@type\\\": \\\"Organization\\\",\\r\\n    \\\"name\\\": \\\"\\\",\\r\\n    \\\"logo\\\": {\\r\\n      \\\"@type\\\": \\\"ImageObject\\\",\\r\\n      \\\"url\\\": \\\"\\\"\\r\\n    }\\r\\n  },\\r\\n  \\\"datePublished\\\": \\\"\\\"\\r\\n}\\r\\n<\\/script>\"]', '[[null,null]]', '[[null,null]]', '[[null,null]]', '[[\"faqs 1\",\"<p>ans faq 1<\\/p>\"],[\"faq 2\",\"<p>ans faq 2<\\/p>\"],[\"faq 3\",\"<p>ans faq 3<\\/p>\"],[\"faq 4\",\"<p>ans faq 4<\\/p>\"],[\"faq 5\",\"<p>ans faq 5<\\/p>\"],[\"faq 6\",\"<p>ans faq 6<\\/p>\"],[\"faq 7\",\"<p>ans faq 7<\\/p>\"],[\"faq 8\",\"<p>ans faq 8<\\/p>\"],[\"faq 9\",\"<p>ans faq 9<\\/p>\"],[\"faq 10\",\"<p>ans faq 10<\\/p>\"]]', 'health,fruit', '<h2 style=\"text-align: center;\"><span style=\"color: #236fa1; background-color: #ffffff;\">1 -&nbsp;<span id=\"overview-of-fruits\"></span>Overview Of Fruits</span></h2>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<p style=\"text-align: justify;\">Food is one of the basic needs of the human body to stay alive. Fruits are a vital part of food that provides vitamins, potassium, fiber, folate, calcium, iron and other minerals to our body. If we desire to live healthily and fit we have to append fruits in our daily lives. Fruits are natural and they can be used to cure many swear diseases like heart diseases, blood pressure, cancer, diabetes, diarrhea, body infection, and other major diseases. Fruits are not only used to cure harmful diseases but they are very effective for&nbsp;skin beauty&nbsp;because they give freshness and beauty to our skin and provide protection to our skin from sun and skin infections. Fruits are also very good for eyes, tooth whitening, and hair growth.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p><img class=\"lazy\" title=\"Fruits 1\" src=\"https://freenology.com/images/thumb-900/fruits-1.jpg\" alt=\"Fruits 1\" width=\"100%\" /></p>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">Every fruit has its own color and taste. Some people like sweet fruits and others like acid fruits. People who do not eat fruits may face many problems like eyesight problems, skin infection, lack of energy,&nbsp;<a class=\"ilgen\" href=\"https://freenology.com/hair-fall-treatment-homemade-tips-to-avoid-hair-fall-2101\" target=\"_blank\" rel=\"noopener\">hair fall</a>, and other major diseases.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h2 style=\"text-align: center;\"><span style=\"color: #236fa1; background-color: #ffffff;\">2 -&nbsp;<span id=\"fruits-advantages-and-disadvantages\"></span>Fruits Advantages And Disadvantages</span></h2>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<p style=\"text-align: justify;\">As we all know that fruits are very healthy for our bodies but, excess for everything is bad. Normally there are very few disadvantages of fruits as compared to their benefits.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4><span style=\"color: #2dc26b;\">Following Are Some&nbsp;<em>Benefits And Disadvantages Of Fruits</em>;</span></h4>\r\n<div>&nbsp;</div>\r\n<h3><span style=\"color: #236fa1;\">2.1 -&nbsp;<span id=\"apple\"></span>Apple</span></h3>\r\n<div>&nbsp;</div>\r\n<p><img class=\"lazy\" title=\"Apple\" src=\"https://freenology.com/images/thumb-900/apple.jpg\" alt=\"Apple\" width=\"100%\" /></p>\r\n<p>&nbsp;</p>\r\n<h4><span style=\"color: #236fa1;\">Benefit</span></h4>\r\n<div class=\"green-text\">\r\n<p style=\"text-align: justify;\">Apples contain antioxidants called flavonoids, which may reduce the chance of diabetes and asthma. Apples are also a natural mouth freshener and they clean our teeth with each juicy bite.&nbsp;Apple&nbsp;is very good for skin it brings freshness to the skin. Apples are used to reduce the cholesterol level by 16 percent.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n</div>\r\n<h4><span style=\"color: #236fa1;\">Disadvantage</span></h4>\r\n<div class=\"red-text\">\r\n<p style=\"text-align: justify;\">The disadvantage of apple is it has a high amount of calories due to sugar so it may create some problems for diabetic patients.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n</div>\r\n<h3><span style=\"color: #236fa1;\">2.2 -&nbsp;<span id=\"banana\"></span>Banana</span></h3>\r\n<div>&nbsp;</div>\r\n<p><img class=\"lazy\" title=\"Banana 1\" src=\"https://freenology.com/images/thumb-900/banana-1.jpg\" alt=\"Banana 1\" width=\"100%\" /></p>\r\n<p>&nbsp;</p>\r\n<h4><span style=\"color: #236fa1;\">Benefit</span></h4>\r\n<div>&nbsp;</div>\r\n<div class=\"green-text\">\r\n<p style=\"text-align: justify;\">Bananas have 105 calories, 3 grams of fiber, source of vitamin B6, potassium and folate.&nbsp;Banana&nbsp;helps to control the blood pressure of our bodies. Banana is very effective for skin. One of the plus points of&nbsp;banana&nbsp;is it can reduce depression.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n</div>\r\n<h4><span style=\"color: #236fa1;\">Disadvantage</span></h4>\r\n<div class=\"red-text\">\r\n<p style=\"text-align: justify;\">The disadvantage of banana is it has low self-stability. The prolonged the life of banana is just for three to five days in the refrigerator.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n</div>\r\n<h3><span style=\"color: #236fa1;\">2.3 -&nbsp;<span id=\"grape\"></span>Grape</span></h3>\r\n<div>&nbsp;</div>\r\n<p><img class=\"lazy\" title=\"Grape 2\" src=\"https://freenology.com/images/thumb-900/grape-2.jpg\" alt=\"Grape 2\" width=\"100%\" /></p>\r\n<p>&nbsp;</p>\r\n<h4><span style=\"color: #236fa1;\">Benefit</span></h4>\r\n<div>&nbsp;</div>\r\n<div class=\"green-text\">\r\n<p style=\"text-align: justify;\">125-milliliter&nbsp;grapes&nbsp;juice contains 53 calories, less than 1 grams of fiber.&nbsp;Grapes&nbsp;contain resveratrol, an antioxidant that may help cure heart diseases by decreasing blood pressure levels and reducing the risk of blood clots.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n</div>\r\n<h4><span style=\"color: #236fa1;\">Disadvantage:</span></h4>\r\n<div>&nbsp;</div>\r\n<div class=\"red-text\">\r\n<p style=\"text-align: justify;\">The disadvantage of grape health is it may cause an allergy that is very dangerous for health.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n</div>\r\n<h3><span style=\"color: #236fa1;\">2.4 -&nbsp;<span id=\"mango\"></span>Mango</span></h3>\r\n<div>&nbsp;</div>\r\n<p><img class=\"lazy\" title=\"Mango\" src=\"https://freenology.com/images/thumb-900/mango.jpg\" alt=\"Mango\" width=\"100%\" /></p>\r\n<p>&nbsp;</p>\r\n<h4><span style=\"color: #236fa1;\">Benefit:</span></h4>\r\n<div>&nbsp;</div>\r\n<div class=\"green-text\">\r\n<p style=\"text-align: justify;\">Mango contains 54 calories, 1.5 grams of fiber. Mango is a source of vitamins A and E. Mangoes are high in the antioxidants lutein and zeaxanthin, which may help protect the vision and reduce the risk of age-related macular degeneration. Mango can be used as an anti-aging cream.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n</div>\r\n<h4><span style=\"color: #236fa1;\">Disadvantage</span></h4>\r\n<div>&nbsp;</div>\r\n<div class=\"red-text\">\r\n<p style=\"text-align: justify;\">The disadvantage of mango is it contains a lot of calories and sugar that can increase your weight.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n</div>\r\n<h3><span style=\"color: #236fa1;\">2.5 -&nbsp;<span id=\"orange\"></span>Orange:</span></h3>\r\n<div>&nbsp;</div>\r\n<p><img class=\"lazy\" title=\"Orange\" src=\"https://freenology.com/images/thumb-900/orange.jpeg\" alt=\"Orange\" width=\"100%\" /></p>\r\n<p>&nbsp;</p>\r\n<h4><span style=\"color: #236fa1;\">Benefit:</span></h4>\r\n<div>&nbsp;</div>\r\n<div class=\"green-text\">\r\n<p style=\"text-align: justify;\">Orange&nbsp;contains 62 calories, 3 grams fiber, source of vitamin C, folate and potassium. Oranges are a good supply of folate, an important vitamin for females for their&nbsp;skin beauty. They also contain a phytochemical called hesperidin, which may minimize cholesterol levels. The natural oil in oranges keeps your skin fresh and young.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n</div>\r\n<h4><span style=\"color: #236fa1;\">Disadvantage:</span></h4>\r\n<div>&nbsp;</div>\r\n<div class=\"red-text\">\r\n<p style=\"text-align: justify;\">The disadvantage of orange is that Oranges do not provide fats but it is high in calories. It has many vitamins, your body needs dietary fats to absorb these vitamins. So oranges lack fats.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n</div>\r\n<p><img class=\"lazy\" title=\"Fruits Benefits 3\" src=\"https://freenology.com/images/thumb-900/fruits-benefits-3.jpg\" alt=\"Fruits Benefits 3\" width=\"100%\" /></p>\r\n<p>&nbsp;</p>\r\n<h3><span style=\"color: #236fa1;\">2.6 -&nbsp;<span id=\"peach\"></span>Peach:</span></h3>\r\n<div>&nbsp;</div>\r\n<p><img class=\"lazy\" title=\"Peach\" src=\"https://freenology.com/images/thumb-900/peach.jpg\" alt=\"Peach\" width=\"100%\" /></p>\r\n<p>&nbsp;</p>\r\n<h4><span style=\"color: #236fa1;\">Benefit:</span></h4>\r\n<div>&nbsp;</div>\r\n<div class=\"green-text\">\r\n<p style=\"text-align: justify;\">Peach has 58 calories, 2 grams of fiber, source of vitamin A. High in vitamin A, peaches help out to control the immune system and can prevent infections.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n</div>\r\n<h4 style=\"text-align: justify;\"><span style=\"color: #236fa1;\">Disadvantage:</span></h4>\r\n<div>&nbsp;</div>\r\n<div class=\"red-text\">\r\n<p style=\"text-align: justify;\">The disadvantage is it may increase your weight.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n</div>\r\n<h3><span style=\"color: #236fa1;\">2.7 -&nbsp;<span id=\"pear\"></span>Pear:</span></h3>\r\n<div>&nbsp;</div>\r\n<p><img class=\"lazy\" title=\"Pear\" src=\"https://freenology.com/images/thumb-900/pear.jpg\" alt=\"Pear\" width=\"100%\" /></p>\r\n<p>&nbsp;</p>\r\n<h4><span style=\"color: #236fa1;\">Benefit:</span></h4>\r\n<div>&nbsp;</div>\r\n<div class=\"green-text\">\r\n<p style=\"text-align: justify;\">Pear has 96 calories, 5 grams of fiber. Pear contains fiber, which can help prevent constipation. Soluble fiber also helps reduce cholesterol levels and reduce the risk of heart disease.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n</div>\r\n<h4><span style=\"color: #236fa1;\">Disadvantage:</span></h4>\r\n<div>&nbsp;</div>\r\n<div class=\"red-text\">\r\n<p>The disadvantage of pear is if you cut it, its color becomes black after some time.</p>\r\n<p>&nbsp;</p>\r\n</div>\r\n<h3><span style=\"color: #236fa1;\">2.8 -&nbsp;<span id=\"pineapple\"></span>Pineapple:</span></h3>\r\n<div>&nbsp;</div>\r\n<p><img class=\"lazy\" title=\"Pineapple Fruit\" src=\"https://freenology.com/images/thumb-900/pineapple-fruit.jpg\" alt=\"Pineapple Fruit\" width=\"100%\" /></p>\r\n<p>&nbsp;</p>\r\n<h4><span style=\"color: #236fa1;\">Benefit:</span></h4>\r\n<div>&nbsp;</div>\r\n<div class=\"green-text\">\r\n<p style=\"text-align: justify;\">Pineapple contains 40 calories, 1 gram of fiber. Pineapples include an ordinary enzyme called bromelain, which transforms protein that helps indigestion. Bromelain may also help to prevent blood clots, growth of cancer cells and it is also used for immediate wound healing.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n</div>\r\n<h4><span style=\"color: #236fa1;\">Disadvantage:</span></h4>\r\n<div>&nbsp;</div>\r\n<div class=\"red-text\">\r\n<p style=\"text-align: justify;\">The disadvantage of&nbsp;<a class=\"ilgen\" href=\"https://freenology.com/pineapple-a-healthy-fruit-benefits-and-side-effects-2108\" target=\"_blank\" rel=\"noopener\">pineapple</a>&nbsp;is, it contains high fructose content that is not beneficial for diabetics patients or people who want to lose weight.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n</div>\r\n<h3><span style=\"color: #236fa1;\">2.9 -&nbsp;<span id=\"pomegranate\"></span>Pomegranate:</span></h3>\r\n<div>&nbsp;</div>\r\n<p><img class=\"lazy\" title=\"Pomegranate\" src=\"https://freenology.com/images/thumb-900/pomegranate.jpg\" alt=\"Pomegranate\" width=\"100%\" /></p>\r\n<p>&nbsp;</p>\r\n<h4><span style=\"color: #236fa1;\">Benefit:</span></h4>\r\n<div>&nbsp;</div>\r\n<div class=\"green-text\">\r\n<p style=\"text-align: justify;\">Pomegranate is a very delicious fruit that contains 53 calories, 1 gram of fiber, source of vitamin A and potassium. Pomegranates contain antioxidant tannins, which may defend the heart. Pomegranates are used to lower down the levels of high blood pressure.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n</div>\r\n<h4><span style=\"color: #236fa1;\">Disadvantage:</span></h4>\r\n<div>&nbsp;</div>\r\n<div class=\"red-text\">\r\n<p style=\"text-align: justify;\">The disadvantage of Pomegranates is, it contains more calories per serving than several other fruits.1-cup of pomegranate boosts our caloric intake by 144 calories so it may create some problems for fat people.</p>\r\n</div>', 'http://ans-blog.unifyp.com/images/fruits-benefits-1-1.jpg', NULL, '1', 318, '2021-04-03 09:41:32', '2021-04-24 17:06:09'),
(21, '10', 1, 'Advantages and Disadvantages | Social Media Overview', 'advantages-and-disadvantages-social-media-overview', 'Advantages and Disadvantages | Social Media Overview', 'Social media is a medium of communication with each other around the world. There are many advantages of social media like millions of people communicate....', 'social,media,social media,tech,advantages and disadvantages', '[\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\\",\\r\\n  \\\"@type\\\": \\\"Article\\\",\\r\\n  \\\"headline\\\": \\\"\\\",\\r\\n  \\\"image\\\": \\\"\\\",  \\r\\n  \\\"author\\\": {\\r\\n    \\\"@type\\\": \\\"\\\",\\r\\n    \\\"name\\\": \\\"\\\"\\r\\n  },  \\r\\n  \\\"publisher\\\": {\\r\\n    \\\"@type\\\": \\\"Organization\\\",\\r\\n    \\\"name\\\": \\\"\\\",\\r\\n    \\\"logo\\\": {\\r\\n      \\\"@type\\\": \\\"ImageObject\\\",\\r\\n      \\\"url\\\": \\\"\\\"\\r\\n    }\\r\\n  },\\r\\n  \\\"datePublished\\\": \\\"\\\"\\r\\n}\\r\\n<\\/script>\",\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\\",\\r\\n  \\\"@type\\\": \\\"Article\\\",\\r\\n  \\\"headline\\\": \\\"\\\",\\r\\n  \\\"image\\\": \\\"\\\",  \\r\\n  \\\"author\\\": {\\r\\n    \\\"@type\\\": \\\"\\\",\\r\\n    \\\"name\\\": \\\"\\\"\\r\\n  },  \\r\\n  \\\"publisher\\\": {\\r\\n    \\\"@type\\\": \\\"Organization\\\",\\r\\n    \\\"name\\\": \\\"\\\",\\r\\n    \\\"logo\\\": {\\r\\n      \\\"@type\\\": \\\"ImageObject\\\",\\r\\n      \\\"url\\\": \\\"\\\"\\r\\n    }\\r\\n  },\\r\\n  \\\"datePublished\\\": \\\"\\\"\\r\\n}\\r\\n<\\/script>\"]', '[[null,null]]', '[[null,null]]', '[[null,null]]', '[[null,null]]', 'good, bad,applocation', '<p>In this article we will make a Laravel blog application&nbsp;with the following features:</p>\r\n<p>[[green:2]]</p>\r\n<ol>\r\n<li>Anyone can log in/register</li>\r\n<li>Users can be \'admin\', \'author\', or \'subscriber\'.</li>\r\n<li>Authors can write/update/delete their own posts.</li>\r\n<li>Admin has full access to the website and can read/ write/ update/ delete any of the posts.</li>\r\n<li>Anyone can read these posts</li>\r\n<li>Users can comment on the posts (only after login)</li>\r\n</ol>\r\n<h2>Demo:</h2>\r\n<p>[[green:2]]</p>\r\n<p>The demo of the application is hosted on Heroku.&nbsp;<a href=\"http://sweet-blog.herokuapp.com/\" target=\"_blank\" rel=\"nofollow noopener\">View Demo</a>. By default, users are authors (so that&nbsp;you can see the&nbsp;complete demo). Your email is required to avoid spam users. Your email will neither be shared with a third party nor be used by us for sending emails. (Although if you do&nbsp;want to receive relevant tutorial emails from us, you can subscribe!)</p>\r\n<figure><img class=\"lazy\" src=\"http://res.cloudinary.com/findalltogether/image/upload/v1445904214/k9agnczu87n9uwlx7zfx.jpg\" alt=\"Single page of demo blogging website\" data-image=\"7i52i5ikj1pl\" /></figure>\r\n<h2>Source code:</h2>\r\n<p>The source code of this application is on Github.&nbsp;<a title=\"Source code for laravel blog on github\" href=\"https://github.com/28harishkumar/blog\" target=\"_blank\" rel=\"nofollow noopener\">Code on Github</a>. This code is open source&nbsp;and you can use and modify it for your projects.</p>\r\n<h2>Pre-requirements:</h2>\r\n<h4>Knowledge:</h4>\r\n<p>This series is written with an assumption that readers are newbies to the Laravel framework but have some experience with PHP. If you don\'t know PHP then use my&nbsp;<a title=\"Step by step php tutorials series\" href=\"http://www.flowkl.com/wp/step-by-step-php-tutorials/\" target=\"_blank\" rel=\"noopener\">Step by step PHP tutorials series</a>. For Laravel tutorials read&nbsp;<a title=\"Laravel tutorials\" href=\"http://www.flowkl.com/wp/tag/laravel-tutorials/\" target=\"_blank\" rel=\"noopener\">Laravel Tutorials</a>.</p>\r\n<h4>Softwares:</h4>\r\n<p>Installed PHP, Mysql, Laravel<strong><br /></strong></p>\r\n<p><strong>NOTE</strong>: If you are working with JSON APIs, you would like my latest post&nbsp;<a href=\"https://www.flowkl.com/article/web-development/passport-authentication-via-access-token-demo-in-laravel/\">Passport authentication using access token demo in Laravel</a>.</p>\r\n<p>&nbsp;</p>\r\n<h2>Install Laravel:</h2>\r\n<div class=\"highlight\">\r\n<ol>\r\n<li>\r\n<div class=\"line\">curl -sS https://getcomposer.org/installer | php</div>\r\n</li>\r\n<li>\r\n<div class=\"line\">sudo mv composer.phar /usr/local/bin/composer</div>\r\n</li>\r\n<li>\r\n<div class=\"line\">composer global require laravel/installer</div>\r\n</li>\r\n<li>\r\n<div class=\"line\">laravel new blog</div>\r\n</li>\r\n</ol>\r\n</div>\r\n<p>Now change directory (in terminal) to inside blog directory and use command.</p>\r\n<div class=\"highlight\">\r\n<ol>\r\n<li>\r\n<div class=\"line\">composer require laravel/helpers</div>\r\n</li>\r\n</ol>\r\n</div>\r\n<p>We will use&nbsp;<em>Str::slug</em>&nbsp;helper for creating slug from post title. For starting Laravel app you need to use this command</p>\r\n<div class=\"highlight\">\r\n<ol>\r\n<li>\r\n<div class=\"line\">php artisan serve</div>\r\n</li>\r\n</ol>\r\n</div>\r\n<h3>Content:</h3>\r\n<h4>1. Setup database</h4>\r\n<ul>\r\n<li>Connect with MySQL database</li>\r\n<li>Create posts and comments tables</li>\r\n</ul>\r\n<h4>2. Create Models</h4>\r\n<ul>\r\n<li>Create Post Model</li>\r\n<li>Create Comment Model</li>\r\n<li>Update User model</li>\r\n</ul>\r\n<h4>3. Controllers</h4>\r\n<ul>\r\n<li>PostController</li>\r\n<li>CommentController</li>\r\n</ul>\r\n<h4>4. Define Web Routes</h4>\r\n<h4>5.&nbsp;Build front end</h4>\r\n<ul>\r\n<li>Customize app.blade.php</li>\r\n<li>make home view</li>\r\n<li>Create posts</li>\r\n<li>Show posts</li>\r\n<li>Edit posts</li>\r\n</ul>\r\n<h4>6. Add TinyMCE and Make user profile</h4>\r\n<ul>\r\n<li>Add TinyMCE to posts</li>\r\n<li>Make profile backend</li>\r\n<li>View for profile</li>\r\n</ul>', 'http://ans-blog.unifyp.com/images/social-media.jpg', NULL, '1', 52, '2021-04-03 09:41:32', '2021-04-27 14:27:39'),
(30, '8', 1, 'Future Drones as Ambulance | Future Ambulance Drones', 'future-drones-as-ambulance-future-ambulance-drones', 'Future Drones as Ambulance | Future Ambulance Drones', 'So this 2019 year is ending, and the dawn of the new year 2020 is nigh. It is funny how 2019 was the year of innovations. So many innovative techs emerged.....', 'programming,tech,technology,drone', '[\"<script type=\\\"application\\/ld+json\\\">\\r\\n{\\r\\n  \\\"@context\\\": \\\"https:\\/\\/schema.org\\\",\\r\\n  \\\"@type\\\": \\\"Article\\\",\\r\\n  \\\"headline\\\": \\\"\\\",\\r\\n  \\\"image\\\": \\\"\\\",  \\r\\n  \\\"author\\\": {\\r\\n    \\\"@type\\\": \\\"\\\",\\r\\n    \\\"name\\\": \\\"\\\"\\r\\n  },  \\r\\n  \\\"publisher\\\": {\\r\\n    \\\"@type\\\": \\\"Organization\\\",\\r\\n    \\\"name\\\": \\\"\\\",\\r\\n    \\\"logo\\\": {\\r\\n      \\\"@type\\\": \\\"ImageObject\\\",\\r\\n      \\\"url\\\": \\\"\\\"\\r\\n    }\\r\\n  },\\r\\n  \\\"datePublished\\\": \\\"\\\"\\r\\n}\\r\\n<\\/script>\"]', '[[null,null]]', '[[null,null]]', '[[null,null]]', '[[\"Why Tik Tok app is dangerous?\",\"<div><span class=\\\"ILfuVd NA6bn\\\"><span class=\\\"hgKElc\\\">The first concern many users (and parents of young users) have about TikTok&nbsp;is the way data is stored and potentially shared. ... &ldquo;All of these platforms, at least in part, are monetizing your data. That\'s what they do. And the more data they have, the more money they can make.<\\/span><\\/span><\\/div>\"],[\"Is TikTok a safe app?\",\"<div><span class=\\\"ILfuVd NA6bn\\\"><span class=\\\"hgKElc\\\"> <strong>TikTok<\\/strong>&nbsp;is under national security review by the Committee on Foreign Investment in the U.S. (CFIUS) after lawmakers accused it of censoring some videos to satisfy the Chinese government.<\\/span><\\/span><\\/div>\"],[\"What\'s special about TikTok?\",\"<div>This video app can help you grab attention from global users. Given that 800+ million users are currently active on Tiktok, the chances of you having huge fanbase are higher. Regardless of how many users you have initially, your video gets viewed and liked if it has quality and relevant content. This way you can earn instant fame.<\\/div>\"],[\"Why Tik Tok app is dangerous?\",\"<div><span class=\\\"ILfuVd NA6bn\\\"><span class=\\\"hgKElc\\\"> <strong>TikTok<\\/strong>&nbsp;is under national security review by the Committee on Foreign Investment in the U.S. (CFIUS) after lawmakers accused it of censoring some videos to satisfy the Chinese government.<\\/span><\\/span><\\/div>\"],[\"What\'s special about TikTok?\",\"<div><span class=\\\"ILfuVd NA6bn\\\"><span class=\\\"hgKElc\\\"> <strong>TikTok<\\/strong>&nbsp;is under national security review by the Committee on Foreign Investment in the U.S. (CFIUS) after lawmakers accused it of censoring some videos to satisfy the Chinese government.<\\/span><\\/span><\\/div>\"]]', 'sports,health,harmful', '<h2 style=\"text-align: justify;\"><span style=\"color: #e20808;\">1 -&nbsp;<span id=\"drones-as-the-ambulance-fleet-of-the-future\"></span>Drones As The Ambulance Fleet Of The Future</span></h2>\r\n<div>&nbsp;</div>\r\n<p style=\"text-align: justify;\">So this 2019 year is ending, and the dawn of the new year 2020 is nigh. It is funny how 2019 was the year of innovations. So many innovative techs emerged. Some hit a rock bottom as soon as they were launched, fidget spinners being one of them. Some rose to their peak. It is funny how the stuff told in old magic tales often becomes a reality thanks to the modern tech. The way they are materialized is not how we imagine. For example, you have to replace the flying magic carpet with helicopters. They are safer and better anyways.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h2><span style=\"color: #e20808;\">2 -&nbsp;<span id=\"ambulance-drones-the-invention-of-2019\"></span>Ambulance Drones The Invention Of 2019</span></h2>\r\n<div>&nbsp;</div>\r\n<p style=\"text-align: justify;\">While all other inventions have been given a solid form of reality, one of the things that have been improved quite a lot is the ambulance. Among them, the idea of&nbsp;<strong>future ambulance drones&nbsp;</strong>is an amazing invention In many ways, the imagination of Santa plays out when it comes to the ambulance of modern tech. The things that you end up replacing are sleighing bells with drones. You also get to replace the gifts with medical emergency supplies. So&nbsp;<a class=\"ilgen\" href=\"https://freenology.com/drones-as-the-ambulance-fleet-of-the-future-285\" target=\"_blank\" rel=\"noopener\">future ambulance drones</a>&nbsp;are a thing now!</p>\r\n<p style=\"text-align: justify;\">The ambulances are not digitalized for the first time. For example, a company in the world tale of Zipline (drone designing company) supplies 20% of net blood supplies by using drone technology. This is not the end. Rather this is merely beginning of a much-optimized future. This is because everything is now entering a new age of technology. Several other companies neighboring Tanzania announced that they would also be using the digital ambulances.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\"><img title=\"future-drones\" src=\"http://imran.unifyp.com/images/future-drones.jpg\" alt=\"future-drones\" width=\"100%\" /></p>\r\n<h2>&nbsp;</h2>\r\n<h2><span style=\"color: #e20808;\"><strong>3 -&nbsp;<span id=\"the-usain-progress-of-drones\"></span>The USA In Progress Of</strong>&nbsp;Drones</span></h2>\r\n<div>&nbsp;</div>\r\n<p style=\"text-align: justify;\">In the USA, one would expect the drone tech to be at a peak. However, this is not the case. This is because the country laws didn&rsquo;t allow for conducting unmanned drone tests. In October 2017, Trump signed the resolution. It would now allow for conducting the tests of unmanned drone tests. Who knows what future doors this could open! The following are the points which speak about the progress of the USA in case of the&nbsp;<strong>future of ambulance drones</strong>.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3><span style=\"color: #ba372a;\">3.1 -&nbsp;<span id=\"trump-legislation\"></span>Trump Legislation:</span></h3>\r\n<div>&nbsp;</div>\r\n<p style=\"text-align: justify;\">According to Trump, passing such legislation was a step forward towards making America progressive. He assured that they would be flying their drones faster and in better positions than other countries. Especially this new legislation about drones that Trump passed allows the local governments and communities to conduct their own drone tests.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3><span style=\"color: #ba372a;\">3.2 -&nbsp;<span id=\"amazon-and-google-own-them\"></span>Amazon And Google Own Them:</span></h3>\r\n<div>&nbsp;</div>\r\n<p style=\"text-align: justify;\">For all the tech fervor created by the passing legislation, companies like Amazon and Google seem to be still a lot behind when compared to the ideal progress. However, it is hoped that they will exceed their own expectations within a short span of time.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3><span style=\"color: #ba372a;\">3.3 -&nbsp;<span id=\"zipline-the-only-company-with-pragmatic-ambulance-drones-for-future\"></span>Zipline, The Only Company With Pragmatic Ambulance Drones For Future:</span></h3>\r\n<div>&nbsp;</div>\r\n<p style=\"text-align: justify;\">The CEO of Zipline said that the government has become quite stagnant with their policies. He also gave a few thoughts about becoming the leading technology in such policies issued by the government. In an interview with a tech enthusiast of Tech Crunch, a blog about technology, the CEO explained some of the vital facts about issues raised in drone development. The issues are not of design; rather they are pure of investment nature. Given below are some of the significant questions that were asked and answered by the CEO.</p>\r\n<p>&nbsp;</p>\r\n<p><img title=\"future-drones-2\" src=\"http://imran.unifyp.com/images/future-drones-2.jpg\" alt=\"future-drones-2\" width=\"100%\" /></p>\r\n<h2>&nbsp;</h2>\r\n<h2><span style=\"color: #ba372a;\">4 -&nbsp;<span id=\"questions-about-company-involved-in-drone-research-on-healthcare\"></span>Questions About Company Involved In Drone Research On Healthcare</span></h2>\r\n<div>&nbsp;</div>\r\n<p style=\"text-align: justify;\">These questions were asked by the CEO of Zipline, a famous company that issues drone\'s products. The following questions display not only the status of the company as an innovative company; they also show what the company is doing. It is also known by looking at these questions that show the progress of this research.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<div class=\"green-text\" style=\"text-align: justify;\">Q. What is the role of Zipline? How is the development of drones for healthcare going?</div>\r\n<div class=\"green-text\" style=\"text-align: justify;\">&nbsp;</div>\r\n<p style=\"text-align: justify;\">Ans: Zipline is one of those companies that are working day and night to build a better future for the people. One of these things is that they strive to achieve is to deliver urgent medical products. Most often, the output that can be achieved by drones cannot be achieved by ambulances. Part of our drone practices also includes delivering blood supplies. We have already implemented some of our drones to deliver the blood supplies.</p>\r\n<p>&nbsp;</p>\r\n<div class=\"green-text\" style=\"text-align: justify;\">Q. What is the average rate of delivery?</div>\r\n<p style=\"text-align: justify;\">Ans: Currently the quest for improvement is going on. On average, the drones were capable of delivering about 20 deliveries per faculty. The deliveries are also going forward in terms of numbers. The 20 delivery rate per week is intended to increase.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h2><span style=\"color: #e20808;\">5 -&nbsp;<span id=\"life-saving-story-of-ambulance-drones\"></span>Life-Saving Story Of Ambulance Drones</span></h2>\r\n<div>&nbsp;</div>\r\n<p style=\"text-align: justify;\">While these two questions don&rsquo;t answer much of everything, the drone&rsquo;s deliveries in Tanzania are bound to prove useful. In Africa as well as Tanzania, these drones are proving immensely useful in blood delivering purposes. It is expected of them to even grow in business and use it for the future.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3><span style=\"color: #ba372a;\">5.1 -&nbsp;<span id=\"the-life-of-young-woman-saved\"></span>The Life Of Young Woman Saved:</span></h3>\r\n<div>&nbsp;</div>\r\n<p style=\"text-align: justify;\">A practical insight over their use will be demonstrated by this story. A young woman in Tanzania who was giving birth started bleeding heavily. She had a critical condition. Even though doctors tried giving her the blood there, the supplies weren&rsquo;t enough.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">The doctors had to travel a few miles to the hospital which would take nearly a few hours. The young woman didn&rsquo;t have that kind of time.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">The doctors instead sent these drones to the hospital. The drones were successful in bringing the blood on time to the spot which saves the young woman&rsquo;s life.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h2><span style=\"color: #e20808;\">6 -&nbsp;<span id=\"conclusion\"></span>Conclusion:</span></h2>\r\n<div>&nbsp;</div>\r\n<p style=\"text-align: justify;\">The following conclusion can be drawn about the ambulance drones.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">1. Ambulance drones are slowly becoming more popular.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">2. The USA has little restrictions on its usage. However, companies like Google and Amazon are developing them. The only Company that currently invests in their usage is Zipline.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">3. Drones have saved countless lives of people, especially in Africa and Tanzania.</p>\r\n<p style=\"text-align: justify;\">[[faqs:1-3]]</p>', 'http://ans-blog.unifyp.com/images/future-drones-1-1.jpg', 'http://blog.dgp/images/2-370x208.jpg', '1', 788, '2021-04-08 13:22:23', '2021-05-11 18:28:56'),
(31, '1,8', 1, 'Sedentary Lifestyle Effects And Risks', 'sedentary-lifestyle-effects-and-risks', 'Sedentary Lifestyle Effects And Risks', 'Sedentary Lifestyle Effects And Risks Sedentary Lifestyle Effects And Risks', 'sadantary,tags', '[null]', '[[null,null]]', '[[null,null]]', '[[null,null]]', '[[\"Question\",\"<p>Answer<\\/p>\"]]', 'simply,kids', '<h2 style=\"text-align: left;\">&nbsp;</h2>\r\n<h2 style=\"text-align: left;\"><span style=\"color: #236fa1; background-color: #ffffff;\">Hating To Play Sports Is Bad, Like Really Bad!</span></h2>\r\n<p style=\"text-align: justify;\">The first criticism which arises here is that some people are not naturally inclined towards sports. When I put the word of loving of sports here, I don&rsquo;t mean the need to start memorizing the football or cricket rules or team players&rsquo; names. Damn it that sucks! No! What I mean here is that you simply adjust to loving sports as part of your daily activity.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p><img class=\"lazy\" title=\"Love Sports\" src=\"https://freenology.com/images/thumb-900/love-sports.jpg\" alt=\"Love Sports\" width=\"100%\" /></p>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">The modern age of tech has approached. As a guy who is in his early twenties, I can tell you that I did grow up in an age where sports were once pretty popular. I am one of those 90s kids who aren&rsquo;t kids anymore. We are officially young adults if this makes anyone happy.&nbsp;<strong>Why should we love sports</strong>&nbsp;then?</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">I have seen a society where we all loved cricket or some other sport. I used to get intensely bored in the afternoon when all the other children were playing outside. Usually, at that time, there wasn&rsquo;t anything good on TV and there was no concept of a computer.</p>\r\n<h2 style=\"text-align: center;\"><span style=\"background-color: #ffffff; color: #236fa1;\">2 -&nbsp;<span id=\"children-of-today-are-not-fan-of-playing-many-sports\"></span>Children Of Today Are Not Fan Of Playing Many Sports:</span></h2>\r\n<div>&nbsp;</div>\r\n<p><img class=\"lazy\" title=\"Not Playing Sports\" src=\"https://freenology.com/images/thumb-900/not-playing-sports.jpg\" alt=\"Not Playing Sports\" width=\"100%\" /></p>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">I remembered passing time while being shy and hiding from others. Then the time changed. Although my childhood passed, I can still see the children of today. Not going outside and playing is pretty normal nowadays. Especially when this age of laptops has provided with enough distractions to keep us busy, we have an increasingly&nbsp;<a class=\"ilgen\" href=\"https://freenology.com/sedentary-lifestyle-effects-risks-2123\" target=\"_blank\" rel=\"noopener\">sedentary lifestyle</a>&nbsp;even in case of kids. The result is increasing rates of obesity even among kids. The kids are experiencing digestion problems which normally arise in adults.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h2 style=\"text-align: center;\"><span style=\"background-color: #ffffff; color: #236fa1;\">3 -&nbsp;<span id=\"sedentary-lifestyle-is-harmful\"></span>Sedentary Lifestyle Is Harmful:</span></h2>\r\n<div>&nbsp;</div>\r\n<p><img class=\"lazy\" title=\"Sedentary Lifestyle Effects\" src=\"https://freenology.com/images/thumb-900/sedentary-lifestyle-effects.jpg\" alt=\"Sedentary Lifestyle Effects\" width=\"100%\" /></p>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">Here is another reason&nbsp;<strong>why you should love sports</strong>. This&nbsp;<a class=\"ilgen\" href=\"https://freenology.com/sedentary-lifestyle-effects-risks-2123\" target=\"_blank\" rel=\"noopener\">sedentary lifestyle</a>&nbsp;is also harmful to the long run. Our life is lived as a mixture of physical and mental energy. We use the brain in office work. However, a healthy body will have a healthy mind. Therefore, if our bodies are not healthy or we didn&rsquo;t cultivate physical strength in our teenage years, we cannot perform well. As a result, diseases like cholesterol or heart diseases are quite common. Our mental energy cannot cope up with weak physical structure then.</p>\r\n<h2 style=\"text-align: center;\"><span style=\"background-color: #ffffff; color: #236fa1;\">4 -&nbsp;<span id=\"playing-the-sports-vs-watching-the-sports\"></span>Playing The Sports VS Watching The Sports:</span></h2>\r\n<div>&nbsp;</div>\r\n<p><img class=\"lazy\" title=\"Watching Sports On Tv\" src=\"https://freenology.com/images/thumb-900/watching-sports-on-tv.jpg\" alt=\"Watching Sports On Tv\" width=\"100%\" /></p>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">I am personally a huge fan of playing sports. I don&rsquo;t like cricket matches or football mind you! I like playing sports or engaging in physical activities with my friends. It gives a great sense of purpose. This article is for people of all ages. For young adults or teenagers, it can easily relate. However, those who are adults, I must tell you that joining a club or sports group is far better than trying to work out on your own. First of all, you will never be regular. 2ndly, you will not enjoy the process. If you join with three to four friends, you will love the process. It will also provide you enough time with your buddies.</p>\r\n<p>&nbsp;</p>\r\n<h2 style=\"text-align: center;\"><span style=\"background-color: #ffffff; color: #236fa1;\">5 -&nbsp;<span id=\"5-effects-and-risks-of-sedentary-lifestyle\"></span>5 Effects And Risks Of Sedentary Lifestyle:</span></h2>\r\n<p>Given below are some of the problems which will result when you have a sedentary lifestyle.</p>\r\n<p><img class=\"lazy\" title=\"Sedentary Lifestyle Risks\" src=\"https://freenology.com/images/thumb-900/sedentary-lifestyle-risks.jpg\" alt=\"Sedentary Lifestyle Risks\" width=\"100%\" /></p>\r\n<h3><span style=\"color: #236fa1;\">5.1 - Circulatory Problems:</span></h3>\r\n<div style=\"text-align: justify;\">&nbsp;</div>\r\n<p style=\"text-align: justify;\">Instead of going into enormous problems that will result as your circulatory system is weakened, I will simply state the benefits of a healthy circulatory system. This is because I care about you whoever is reading this stuff. I don&rsquo;t want to sound ominous.</p>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">Our circulatory system is one of the most crucial systems in our bodies. When it is improved, we can take in lots of fresh air. This fresh air also generates a lot of new and fresh blood. The old cells are discarded fast. Other than this, the heart circulates better blood. This also lowers the rate of cholesterol. Other than this, the internal organs can perform their functions much better with newly oxygenated blood. The body also better detoxifies itself. Reason enough for&nbsp;<strong>why you should love sports!</strong></p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Now imagine the circulatory system growing weaker. I don&rsquo;t need to list the possible potential harms it will cause to your physical as well as mental health. The point of the matter is, do some sports.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3><span style=\"background-color: #ffffff; color: #236fa1;\">5.2 -&nbsp;<span id=\"weight-gain\"></span>Weight Gain:</span></h3>\r\n<div>&nbsp;</div>\r\n<p style=\"text-align: justify;\">Your nice muscles will hide under an enormous layer of fats. I bet you wouldn&rsquo;t like that.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">I think it is pretty obvious that your intake of food must be lower than how much your metabolism can handle. Other than this, you also need to exercise, be it sports or anything else like workouts.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">When you don&rsquo;t maintain the perfect food balance, a few things may happen which will not be liked by you. One of these few things is that you will gain an enormous amount of weight. Other than simple weight gain, your cholesterol levels are bound to increase due to fats piling up on the muscles. The sports encourage your weight and figure to remain manageable and smooth. This will allow for a better management according to your figure.</p>\r\n<p>&nbsp;</p>\r\n<h3><span style=\"color: #236fa1;\">5.3 -&nbsp;<span id=\"diabetes\"></span>Diabetes:</span></h3>\r\n<div>&nbsp;</div>\r\n<p style=\"text-align: justify;\">One of the main reasons for diabetes is a high rate of sugars present in the body which proves harmful for you. This is because not many people are digesting what they are taking in.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Many people eat too much junk food. It is impossible to avoid different types of foods when we are outside. Therefore, you need to exercise to digest the sugars which have a chance of gathering in your body and causing harm.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3><span style=\"color: #236fa1;\">5.4 -&nbsp;<span id=\"mental-effects\"></span>Mental Effects:</span></h3>\r\n<div>&nbsp;</div>\r\n<p style=\"text-align: justify;\">Depression, frustration, unnecessary boredom&hellip; you name any harmful mental effect and I can prove it is somehow related to lack of activity be it mental or physical.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">We face different stress at work and in general life. What makes us keep going?</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">We need to constantly shift our focus on different places. This often constitutes healthy mental activity. This coupled with physical activity is a perfect match for a healthy lifestyle.</p>\r\n<p>&nbsp;</p>\r\n<h3><span style=\"color: #236fa1;\">5.5 -&nbsp;<span id=\"improved-focus\"></span>Improved Focus:</span></h3>\r\n<div>&nbsp;</div>\r\n<p style=\"text-align: justify;\">When we play sports, our focus can be shifted elsewhere. Managing healthy mental activity requires some cultivation of will which is not possible by everyone. This is where the sports come into play. Since most of us respond on a physical level, they allow us to shift our minds elsewhere. Sports also allow serotonin to be released into our systems which is responsible for happiness.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">On the contrary, if you avoid sports or any other physical activity, you will undergo harmful effects. You will not find yourself focusing on productive things. Exhaustion due to stress can be only fought by shifting focus elsewhere.</p>', 'http://ans-blog.unifyp.com/images/sports-outside-1.jpg', 'http://ans-blog.unifyp.com/images/mother-son-embracing-outdoors-on-600w-746201944-370x259.webp', '1', 8, '2021-04-24 17:19:18', '2021-04-27 15:26:34');
INSERT INTO `posts` (`id`, `category_id`, `author_id`, `post_title`, `slug`, `meta_title`, `meta_description`, `meta_tags`, `post_schema`, `green_text`, `red_text`, `black_text`, `faqs`, `internal_tags`, `post_detail`, `post_cover_image`, `post_og_image`, `post_status`, `post_view`, `created_at`, `updated_at`) VALUES
(33, '1', 1, 'Spiritual Dimension', 'spiritual-dimension', 'A Sight on Spiritual Dimension', 'In this journey of life where we reside in our physical forms, we have much to live for. Our bodies are on earth, our mind and bodies reside...', 'mind,bodies,reside', '[null]', '[[null,null]]', '[[null,null]]', '[[null,null]]', '[[null,null]]', NULL, '<h1>Spiritual Dimension</h1>\r\n<p style=\"text-align: justify;\">We, humans, are deeply spiritual beings. In this journey of life where we reside in our physical forms, we have much to live for. Our bodies are on earth, our mind and bodies reside in higher planes of existence. One of those planes of existence is of spirit, also known as a spiritual dimension.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">A few years ago if someone had told me these lines, I would have nothing but ridicule in my mind. However, now the situation has changed a lot. I had my share of awakening when I needed it most. I was the logical person. Always believing in what my senses could perceive. Considering this, the notion of the spiritual dimension was close to fantasy to me. And when the reckoning came, in the form of my teacher who taught me how to truly live other than simple breathing, I realized how foolish I was. At first, I used to ridicule the spiritual people, now I was embarrassed about myself.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">If we depend only on what we see and perceive, we cannot progress. I am speaking in terms of scientific logic. We cannot hear certain frequencies, so we progress to find them out. Similar is the case of the spiritual dimension. Human beings are more than their physical bodies and structures. They are divine beings having a powerful mind and spirit. Only the instruments we need to develop here are our hearts and minds.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Some people are critical of the existence of the spiritual plane. If the blame was to be placed on narrow-minded non-believers, the same amount of blame has to also be given to the religious dogmatism which presents a linear view of a spiritual dimension. The idea of the spiritual dimension is highly non-linear. This is because it is a place where our thought forms reside. Depending on a person&rsquo;s own vibrations, the spiritual plane can either be a safe haven or paradise, or it can easily assume the form of the deepest darkest abyss. Either way, one thing is certain; the spiritual plane is somewhere parallel to us. &nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">My understanding of spiritual plane came when I wanted to realize the higher truths. My first encounter with my lifelong teacher turned me into a believer. I wanted to know where we go after we die. For some, life ends. And I couldn&rsquo;t believe the energy could ever be destroyed. It could be converted into another form. Considering how beautiful a human life is, every human is a walking treasure of emotions, secrets and life struggles. This energy driving every human demanding explanation more than physical form. And that explanation is the spiritual plane. Our consciousness simply finds another way to live. That is the spiritual dimension where we go after our deaths. It is either a paradise, or it is something like a nightmare.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">There is something that is required by a person to access the spiritual dimension. And that is the most difficult thing, especially for someone like me. I was required to have faith in the unknown. I again took the support of science and was surprised how many scientists adopted the faith in the unknown to further their scientific research. Especially if the spiritual dimension is a product of our vibrations in the physical plane, I wanted to reach there.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: center;\"><img title=\"a-sight-on-spiritual-dimension-1\" src=\"http://imran.unifyp.com/images/a-sight-on-spiritual-dimension-1.jpg\" alt=\"a-sight-on-spiritual-dimension-1\" width=\"100%\" /></p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">I followed the concept of a higher consciousness looking after us. There truly is someone who created us and one who loves us. How could it not be! We, humans, are tremendously gifted beings. The spiritual plane is the manifestation plane where our deepest desires or fears are manifested, depending on what we give power to.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Realizing this truth, I stopped focusing on what I had to lose. I started my focus on what I had to gain. What I could become if I could release myself from unhealthy desires and emotions. This is one of the prime aspects of my journey into the spiritual dimension. I had to live my life truly. And the only way to do that was to stop letting it covered by the shadow of fear.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">As I embark on this journey, I realize my training in basic human virtues is still underway. The more I know, the more I realize how much I still have to learn. For me, the goal is to develop those frequencies which will manifest as abundant and rich life from spiritual plane to this plane of existence we call earth, both in life and after death.</p>', 'http://ans-blog.unifyp.com/images/a-sight-on-spiritual-dimension.jpg', NULL, '1', 4, '2021-04-24 17:48:54', '2021-04-26 17:08:03'),
(34, '1', 1, 'Earn Money Quick As Freelance Writer', 'earn-money-quick-as-freelance-writer', 'earn-money-quick-as-freelance-writer', 'Making money easily through freelance writing is not easy. You will learn how to make money fast as a freelance writer. I have read many articles...', 'Earn Money from Writing Freelance,Writing Jobs', '[null]', '[[\"Earning money as a freelance writer\",\"<div>\\r\\n<p style=\\\"padding-left: 30px;\\\">1. Become skilled in any freelance writing niche.<\\/p>\\r\\n<p>&nbsp;<\\/p>\\r\\n<p style=\\\"padding-left: 30px;\\\">2. Market yourself properly and maintain professional clients&rsquo; attitudes.<\\/p>\\r\\n<p>&nbsp;<\\/p>\\r\\n<p style=\\\"padding-left: 30px;\\\">3. Check if you are not making any mistake.<\\/p>\\r\\n<p>&nbsp;<\\/p>\\r\\n<p style=\\\"padding-left: 30px;\\\">4. It is a must check for freelancing vs. doing a regular job article.<\\/p>\\r\\n<\\/div>\"]]', '[[null,null]]', '[[null,null]]', '[[null,null]]', NULL, '<div>\r\n<h2 style=\"text-align: justify;\">[[toc]]</h2>\r\n<h2 style=\"text-align: justify;\">[[t1]]Find out if you are a Natural Born Freelance Writer[[/t1]]</h2>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">You must have heard a lot about freelance writing. Stories of successful freelance writers who are earning a lot of money on a daily or monthly basis must have inspired you a lot.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">So what exactly is freelance writing? How does the system work? What are your chances of success as a beginner? This article is a very comprehensive guide to freelance writing. You will learn <strong>how to make money fast as a freelance writer</strong>.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"text-align: justify;\"><strong>[[t1-s1]]How to Read this Article[[/t1-s1]]</strong></h4>\r\n<h4 style=\"text-align: justify;\">&nbsp;</h4>\r\n<p style=\"text-align: justify;\">Feel free to skip the portions you find irrelevant to your sought interests. While the article is definitely worth your time, it has been written in such a way that you will find what you are looking for in separate paragraphs. You can skip a few, or read all of them for greater benefit.</p>\r\n<p style=\"text-align: justify;\">[[download:1]]</p>\r\n<p style=\"text-align: justify;\">I will not lie to you. <strong>Making money easily through freelance writing </strong>is not easy. You will need to achieve some patient attitude and skills before it comes easy to you. I deliver no sugarcoated promises or those concealed secrets not available to everyone. There is no such thing. The information I am presenting here is available in many other articles too. I have read many articles about <strong>making quick money through freelance writing</strong> and I found myself lacking all the information at once. Therefore, I am writing a very detailed article to convey all the necessary information at once.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"text-align: justify;\"><strong>Making Effective Money vs. Making Fast Money through Freelancing</strong></h4>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">One of the main things that I would like to mention is the difference between <strong>making money effectively as a freelance writer </strong>and <strong>making money quickly by freelance writing. </strong>You will always find many methods to earn your money quickly. The problem is the amount will be either too small or negligible if you are serious about earning. It will have a chance of being enough for your pocket money.</p>\r\n<p style=\"text-align: center;\"><strong>&nbsp;[[download:2]]</strong></p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"text-align: justify;\"><strong>What is Freelance Writing?</strong></h4>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Coming back to freelance writing, freelance writers simply write for money. A distinction between writing job and the freelance writing job can be made on the basis of work schedule and degree of freedom.</p>\r\n<h3 style=\"text-align: justify;\"><strong>Normal Job vs. Freelance Writing Job</strong></h3>\r\n<p style=\"text-align: justify;\">When you are out there working a job, you will be entitled to work during specific hours. When you are <strong>making money effectively using freelance writing, </strong>you will be granted flexibility in terms of your work. This is better or worse, depending on you. Some days you will feel completely liberated from the normal job pressures. Other days, you will be sitting up all night to meet the deadlines of your clients.</p>\r\n<p style=\"text-align: justify;\">[[related:3]]</p>\r\n<p style=\"text-align: justify;\">Also when you are working for a job, you will be set for a rate of pay per hour. However, in freelance writing, there is no such thing. There, you will set the rate yourself depending on quality and productivity.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Another difference I would like to point out is that freelance writing requires time. Unlike a normal job where you will be earning starting from the first month, in freelance writing, you will need to wait to <strong>make money effectively as a freelance writer. </strong>This is because freelance writing depends on many things such as your reputation, your clients&rsquo; ratings, your work expertise, and experience. Therefore, you will be on your own completely.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"text-align: justify;\"><strong>[[t1-s5]]Is Freelance writing for me?[[/t1-s5]]</strong></h4>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">Freelance writing is actually for some people. The idea of working from home sounds great. However, to ignore the complications and reservations is simply sugarcoating a certain topic. Freelancing is great for the people who are adept at rescheduling. This is because where you will feel the joy of being your own boss; you will also be dependent on your clients. Other than this some nights are going to be sleepless since your client&rsquo;s deadline may be tomorrow early morning.</p>\r\n<p style=\"text-align: justify;\">[[related:2]]</p>\r\n<p style=\"text-align: justify;\">To <strong>earn quick money using freelance writing</strong>, you will need to consider many possibilities. Always remember that whether you work from home or you work from an office, work will always be work.</p>\r\n<p style=\"text-align: justify;\"><strong>&nbsp;</strong></p>\r\n<h4 style=\"text-align: justify;\"><strong>[[t1-s5-c1]]What is a freelance writer?[[/t1-s5-c1]]</strong></h4>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">A freelance writer is both a marketer and a writer. When someone has a writing job, all they need is to write and perform the task given to them. However, when someone is <strong>making money effectively as a freelance writer</strong>, they will easily be a writer as well as a skilled marketer to highlight their skills.</p>\r\n<p style=\"text-align: justify;\"><strong>&nbsp;</strong></p>\r\n<h4 style=\"text-align: justify;\"><strong>Why is marketing necessary for making money fast as a freelance writer?</strong></h4>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">Marketing is one of the most crucial aspects of successful freelancing. Especially if you don&rsquo;t use any platforms and wish to earn all by yourself, you will see that marketing is actually necessary. No one will know who you are and how the quality of your work is superb.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Even if you join a freelancing platform, you will still require publishing your services, seeing what your competitors are offering at what prices. All in all, marketing is highly necessary. To <strong>make easy money by freelance writing</strong>, you will need to let people know you. Skills like SEO (search engine optimization), advertisements are crucial.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"text-align: justify;\"><strong>What is Variety of Freelance writing? Importance of niches in making money as freelance writers</strong></h4>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">This depends on many situations. You will be surprised to know that even among the writing types, there niches and sub-niches.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Among all the types of writing, article writing is the most common niche in freelance writing. This is because the articles are always in huge demand. Another reason for this is that articles are the easiest form of freelance writing. Even the ones who are not writers can come up with articles. Article writing is surely one of the easiest ways to <strong>earn money easily as a freelance writer</strong>.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Other types of freelance writing are content writing, website writing, blog writing, ghostwriting for novels and product writing as well as business writing. Note that these are some of the most common types of writings. Freelance writing is a developing field that will keep developing day by day. Therefore, finding your niche is your business.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">You will need to decide on one niche and decide it fast. Then make that niche your strength. You will also need to consider which of the niches are most popular in markets. Then, get some lessons on it from authentic online or local sources. You will be on the track within no time.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"text-align: justify;\"><strong>[[t1-s5-c4]]Who will be my clients?[[/t1-s5-c4]]</strong></h4>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">This question like niches is quite a diverse question with multiple answers. There is no one true answer. This is because the clients are always going to be multiple. Some of your clients may be normal folks trying to pay you for writing their blogs by their name. Some may be script developers, hiring you for ghostwriting. Some of the clients will be company owners who will constantly require you to write about their products. All of these have one thing in common. They will come to you more and more if what you offer is unique and of high quality.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">While meeting clients globally is a wonderful experience that will be made possible by freelancing, caution should be exercised while dealing with clients. Always be professional and always be careful in all of your dealings. This is because some clients are not actually buyers, rather scammers who are out there to scam you into working for free. &nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"text-align: justify;\"><strong>[[t1-s5-c5]]Freelancing Platform or Not?[[/t1-s5-c5]]</strong></h4>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">To <strong>make quick money as a freelance writer</strong>, you will need to join the freelancing platform. This is because every freelancing platform is there for a reason. While there are wonderful examples of people who don&rsquo;t join a freelancing platform due to the commission, there are the majority of people who are members of such platforms.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Starting as a beginner, you will need to join one of the freelancing platforms to <strong>earn money easily as a freelance writer</strong>. The platform will guide you through some basic procedures and publish your services for free. They will cut some percentage of the money the client pays you a commission. Some of the platforms are for beginners like Fiverr. Some of the platforms are for advanced freelancers like freelancer.com.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">When you progress through freelancing, having made up a notable profile at the platform, you can now approach clients and companies on your own through cold emailing and your own website. Having done this, you will get to keep the entire amount without commission to yourself. However, this is not a common practice due to many complications arising on the way to <strong>making quick money as a freelance writer</strong>. This is definitely worth though. Check the pros and cons of freelancing platforms.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h2 style=\"text-align: justify;\">[[t2]]Skills Required for Being a Freelance Writer[[/t2]]</h2>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Now that we have discussed the introductory things about freelance writing, we will switch towards a more training tone. As a beginner, you must be eager to earn money easily as a freelance writer. Given below is a skills list which you will need to develop for making money as a freelance writer.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3 style=\"padding-left: 30px;\"><strong>1.[[t2-s1]] Checking for Spelling Mistakes[[/t2-s1]]:</strong></h3>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">The spelling mistakes can seem like a minor issue to everyone who is a writer. Being a writer for eight years, I can feel humiliated if I feel someone advising me to correct my spellings. This is where things can get interesting. Always check your work whenever you write your pieces. Things are not always good. You can get your grammar checking tools messed up; the spell checker can get bugged (It happens very often!). Reading your piece like a critic can always save you from humiliating mistakes. Other than this, the idea of rechecking depicts not the flaws in your writing, rather you being a caring person. Always remember the following points:</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"padding-left: 30px;\">1. Your work is going to be the property of someone else. Try your best and always recheck.</p>\r\n<p style=\"padding-left: 30px;\">&nbsp;</p>\r\n<p style=\"padding-left: 30px;\">2. Relying too much on computer grammatical tools is unwise. The computer programs are known to cause bugs.</p>\r\n<p style=\"padding-left: 30px;\">&nbsp;</p>\r\n<p style=\"padding-left: 30px;\">3. Checking and rechecking your work indicates you being professional.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3 style=\"padding-left: 30px;\"><strong>2.[[t2-s2]] Following Grammar Rules[[/t2-s2]]:</strong></h3>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">When you are <strong>earning money as a freelance writer</strong>, you will need to strictly follow the grammar rules. Checking for grammar is a different thing, following the grammar structure is another. Therefore, you need to follow the rules. Depending on your work, especially if you are doing the ghostwriting, you may not need it much. However, even should you be a ghostwriter, you will be required at some time to write articles and other writer&rsquo;s work which demands grammatical structure. Therefore, always follow grammatical rules.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3 style=\"padding-left: 30px;\"><strong>3.[[t2-s3]] Proof Reading[[/t2-s3]]:</strong></h3>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">Other than a skill you can offer up in the market, proofreading should always be in your style. This is because proofreading is essential for writing of any kind. The reason is that grammatical computer tools cannot catch proofreading mistakes. You will be surprised to know how many mistakes or sentence structure errors you have in your freshly written piece.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3 style=\"padding-left: 30px;\"><strong>4.[[t2-s4]] Quality of Writing[[/t2-s4]]:</strong></h3>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">When <strong>making quick money as a freelance writer</strong>, you will easily be noticed if you are not a writer. For some, article writing doesn&rsquo;t mean a person is a writer. Anyone can do it. However, when the work becomes long, the article writing is somewhat not suited for everyone. It is quite noticeable who is actually a writer and who is only here for making some <strong>quick money using freelance writing</strong>. Therefore, always be good at your craft of writing before choosing this vocation.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3 style=\"padding-left: 30px;\"><strong>5.[[t2-s5]] Marketing[[/t2-s5]]:</strong></h3>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">The aspect of marketing is a crucial one. When you are out there, <strong>earning money easily as a freelance writer</strong>, you will easily understand how crucial marketing is. Freelance writing is a field of many competitors and its market is always blooming with work. However, no one will know what you offer unless you make yourself known. Good marketing is always a crucial point for any business and freelance writing is a lot like business.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3 style=\"padding-left: 30px;\"><strong>6.[[t2-s6]] Proper Research[[/t2-s6]]:</strong></h3>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">When writing reports, proper research is always necessary. Especially when you are writing articles, your information should always be accurate and worthy of display. Writing on how to eat an <a class=\"ilgen\" href=\"https://freenology.com/benefits-and-disadvantages-of-fruits-2115\" target=\"_blank\" rel=\"dofollow noopener\">apple</a> and conveying apples are poisonous if taken at night is going to be harmful to your articles. Similarly, presenting the information which is self-made without any solid facts is wrong. It will easily get you spotted out in freelancing.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3 style=\"padding-left: 30px;\"><strong>7.[[t2-s7]] Learning[[/t2-s7]]:</strong></h3>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">Learn even if you don&rsquo;t know what to learn anymore. Our thinking can become limited due to knowing more, learning can never be a destination. It is always a process. As it is always said, learning is a bottomless pit. Other than this, learning is also crucial for your trade. When you are offering a niche, learning about other niches can help you hone your own craft too. Other than this, in freelance marketing, you will understand how much learning potential is hidden. Especially when it comes to dealing with clients and handling the advertisements, learning plays an important role.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3 style=\"padding-left: 30px;\"><strong>8.[[t2-s8]] Thinking in terms of Business[[/t2-s8]]:</strong></h3>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">The business can be many things nowadays thanks to the internet and digital age. Freelance writing is also a form of business. When you are handling this <strong>freelance writing to make more money</strong>, you will need to think like a business owner. This is because you are one. You are your own boss and you can easily refuse what you cannot do. You can choose your own clients and you will be responsible for your profile online and clients&rsquo; behavior and reviews.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3 style=\"padding-left: 30px;\"><strong>9.[[t2-s9]] Inner Strength[[/t2-s9]]:</strong></h3>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">Although most people meet good clients, there will also come to some horrible ones. It is the experience of every seller. This is because not everyone is in the market for good money. Some people wish to get their work done for free of cost. I personally call them, &ldquo;<em><strong>evil buyers</strong></em>&rdquo;. These people are there to extort money out of you and getting their work done.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">There are also times when your work is not like what it is used to be every day. Many reasons can be there. In such a case, criticism is inevitable.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Humiliating comments from clients are not to be taken on the heart. Always trust your inner ability. Learn where you can and move on.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">You will also need to be able to say no and draw a boundary where it is needed. Especially when you are new to freelance writing, some will present you with insulting offers like writing 5000 words for 5$. Do not sell your services this low.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3 style=\"padding-left: 30px;\"><strong>10.[[t2-s10]] Professional Attitude[[/t2-s10]]:</strong></h3>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">When approaching clients, always be on your guard. They are not your friends. Always have a professional demeanor when addressing your clients. Always respect deadlines. When <strong>earning quick money using freelance writing</strong>, always keep calm and deliver on time or before that. You will also need to keep a level-headed approach to the clients. A professional attitude will always make you appear above your competitors. It will easily give the impression that you are someone who has been doing this for a long time.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3><strong>&nbsp; &nbsp; 11.[[t2-s11]] Different Writing Styles[[/t2-s11]]:</strong></h3>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">The mastery of different writing styles is another must-have skill in freelance writing. You will obviously need it in starting. Especially when you want to offer many skills at once, you will need to be able to think different. Obviously, when you are writing an article, you will use a different language than used in story or report writing.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h2 style=\"text-align: justify;\">[[t3]]Mistakes to Avoid while Doing Freelance Writing[[/t3]]</h2>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">After I have told you about the skills required for professional freelance writers, I will now convey what mistakes often the newbies make. You will need to check if you are not making any of them. When I started, I had no one to tell me that these mistakes were costing me, clients. Now, I want you to avoid them. Given below is a comprehensive list.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"padding-left: 30px;\"><strong>1.[[t3-s1]] No Checking of the Competitors[[/t3-s1]]:</strong></h4>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">When you are <strong>earning quick money as a freelance writer</strong>, you will understand that checking competitors is very crucial. You should keep a check on what the top gigs in your niche are in the market and what is the reason they are being among the topmost gigs. You should see what they offer at what price. Usually, that is what the people are looking for. So go ahead and customize your niche according to top standards decided by people.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"padding-left: 30px;\"><strong>2.[[t3-s2]] Telling your Clients you are a Newbie[[/t3-s2]]:</strong></h4>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">This is the most unprofessional thing. You cannot be a newbie to writing. You can be a newbie to the market. You decided to write articles because that is something you found you can do. You came to this freelancing trade because you have what it takes. Therefore, NEVER tell any client that you are a newbie. Your gig should always be in your area of expertise.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"padding-left: 30px;\"><strong>3.[[t3-s3]] Making Wrong Gigs[[/t3-s3]]:</strong></h4>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">The gigs should always be in your area of expertise. Do not make a gig of graphics designing after attending some lectures from YouTube. Do not make the gig of writing just because you love reading novels and you think you can write one.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"padding-left: 30px;\"><strong>4.[[t3-s4]] No Proofreading of work[[/t3-s4]]:</strong></h4>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">No proofreading and delivering freshly written pieces is unprofessional practice. It indicates you are doing this for the first time and that is what can give a bad reputation to your profile. Your profile is highly necessary.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"padding-left: 30px;\"><strong>5.[[t3-s5]] No Strong Management System[[/t3-s5]]:</strong></h4>\r\n<p style=\"text-align: justify;\">You will need to manage time when you are <strong>earning money as a freelance writer</strong>. This is because you wish to meet the deadlines professionally. If you fail to do so, you can easily give yourself a bad reputation among the freelancing market.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"padding-left: 30px;\"><strong>6.[[t3-s6]] No Blog, No reputation[[/t3-s6]]:</strong></h4>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">Rightly said, you will need to have a blog if you are a writer. If you are not a blogger, become one. If you are not in the habit of writing articles, develop such a habit. This is because as a writer, when someone asks you to show them your portfolio, you will need to have a blog to show. It will display a lot of things. Being a writer, having a website for your portfolio is a must.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"padding-left: 30px;\"><strong>7.[[t3-s7]] Having a Non-Professional Attitude[[/t3-s7]]:</strong></h4>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\">This can encompass multiple things such as,</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"padding-left: 30px;\">1. Maintaining a non-professional communication with your clients.</p>\r\n<p style=\"padding-left: 30px;\">&nbsp;</p>\r\n<p style=\"padding-left: 30px;\">2. Having not enough knowledge about marketing and platform you are using</p>\r\n<p style=\"padding-left: 30px;\">&nbsp;</p>\r\n<p style=\"padding-left: 30px;\">3. Asking irrelevant questions from clients</p>\r\n<p style=\"padding-left: 30px;\">&nbsp;</p>\r\n<p style=\"padding-left: 30px;\">4. Never thinking outside the box</p>\r\n<p style=\"padding-left: 30px;\">&nbsp;</p>\r\n<p style=\"padding-left: 30px;\">5. Never learning from mistakes</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: center;\"><img title=\"Make Quick Money As A Freelance Writer 1\" src=\"https://freenology.com/images/thumb-900/make-quick-money-as-a-freelance-writer-1.jpg\" alt=\"Make Quick Money As A Freelance Writer 1\" width=\"902\" height=\"383\" /></p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h2 style=\"text-align: justify;\">[[t4]]Types of Freelance Writing[[/t4]]</h2>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Freelance writing is a huge niche. It is continuously expanding and changing. It covers many niches. Some of them are quite what you wish to do such as story writing. Some of them are strictly professional in their nature such as reports. Always remember being a writer doesn&rsquo;t mean you will easily be able to become professional in all types of writing without manual help. You may be good at some of them, while some may not be your expertise.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"padding-left: 30px;\"><strong>1.[[t4-s1]] E-book Writer[[/t4-s1]]:</strong></h4>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">You can <strong>easily earn money using freelance writing</strong> through E-book writing. E-books can be on different topics. You should see the different guidelines.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"padding-left: 30px;\"><strong>2.[[t4-s2]] Report Writing[[/t4-s2]]</strong>:</h4>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Report writing or technical writing is another one of hot niches. You should be capable of using formal English for the intended report. Other than this, you should also be able to follow a certain structure.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"padding-left: 30px;\"><strong>3.[[t4-s3]] Research Writing[[/t4-s3]]:</strong></h4>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">When making money, research writing is another one of niches which you will find thriving to this day. In the world of freelance marketing, whether it is the usual academic writing or a company&rsquo;s report about certain facts, your job would be to research them and present them in a suitable form.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"padding-left: 30px;\"><strong>4.[[t4-s4]] Political Writing[[/t4-s4]]:</strong></h4>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\"><strong>Earning money fast as a freelance writer</strong> can also be done through political blogging. You can easily offer your services as a political writer. Other than normal political blogs, you can join certain newspapers or political magazines and write for them.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"padding-left: 30px;\"><strong>5.[[t4-s5]] Business Writing[[/t4-s5]]:</strong></h4>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Business writing is another hot topic that pays a lot. This is because business writing is highly valued in markets. You will be writing success stories of a product or services. Creating new stories for brands is what you will be performing as your job. Not every freelance writer can offer this as it takes skills to do successful business writing.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"padding-left: 30px;\"><strong>6.[[t4-s6]] SEO and Digital Marketing Writers[[/t4-s6]]</strong>:</h4>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Digital marketing and search engine optimization (SEO), both are highly popular fields for making money. This SEO and Digital Marketing writers can make a lot of money if they know their trade and about writing.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h4 style=\"padding-left: 30px;\"><strong>7.[[t4-s7]] Content Writing[[/t4-s7]]:</strong></h4>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">You will be writing content for a product or website online under this niche. The requirements are to have a flexible writing style, adjust according to product or service described and audience targeted.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h2 style=\"text-align: justify;\">[[t5]]Conclusion[[/t5]]:</h2>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\"><strong>Earning money as a freelance writer </strong>is quite possible easily and effectively if you focus on the following things:</p>\r\n<p>[[green:1]]</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n</div>', 'http://ans-blog.unifyp.com/images/make-quick-money-as-a-freelance-writer-200x131.jpg', NULL, '1', 14, '2021-04-24 17:53:16', '2021-04-28 12:03:26'),
(35, '1', 1, 'Building Relationships - Business Networking Tips 2020', 'building-relationships-business-networking-tips-2020', 'Building Relationships - Business Networking Tips 2020', 'Building Relationships With Influencers - Business Networking Tips 2020', 'business,topbusiness,businesstip', '[null]', '[[null,null]]', '[[null,null]]', '[[null,null]]', '[[null,null]]', NULL, '<h1><img style=\"display: block; margin-left: auto; margin-right: auto;\" title=\"make-quick-money-as-a-freelance-writer-200x131\" src=\"http://ans-blog.unifyp.com/images/make-quick-money-as-a-freelance-writer-200x131.jpg\" alt=\"make-quick-money-as-a-freelance-writer-200x131\" width=\"500\" /></h1>\r\n<h1 style=\"text-align: justify;\">Building Relationships With Influencers - Business Networking Tips 2020</h1>\r\n<div>&nbsp;</div>\r\n<p style=\"text-align: justify;\">Everyone who is an entrepreneur or businessman knows the importance of networking. They say your company determines what kind of person you are. This statement carries special significance when it comes to the business world.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">One of the most important steps in building a strong network is that get to know the right kind of people. How exactly to know the right kind of people?</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Some people are so desperate in getting to know the right people in the first turn. They end up wasting so many resources. In the end, they are back where they started.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\"><strong><img title=\"who-is-an-influencer-1\" src=\"http://imran.unifyp.com/images/who-is-an-influencer-1.jpg\" alt=\"who-is-an-influencer-1\" width=\"100%\" /></strong></p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Then there is a less risky approach. Instead of approaching people on own, people start relying on other people. This is not as effective as some may think. People simply start thinking that by doing such a thing, they will reduce their risks. What they don&rsquo;t know is that people who are helping them are usually like them. I am not saying to not bond with people. I am saying that bonding with people is nice; just make sure to get your opinion involved in your process.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">One of the most crucial steps in building a network is to approach people on our own. Like other things, there is always room for improvement. Not only this, but there is also room for learning. Apart from this, when someone lets you meet another person, you are using a medium. Instead, approaching directly builds experience. There is no better confidence builder than experience.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">These several tips are there from a successful entrepreneur who owns this website. These tips helped him get far in life. Keep in mind one thing. These are not the list of habits which you should adopt. Everybody has to make their own effective habits to be adopted.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">[[toc]]</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h2 style=\"text-align: justify;\"><span style=\"color: #ba372a;\">1 - [[t1]]Tips For Effective Networking[[/t1]]:</span></h2>\r\n<div>&nbsp;</div>\r\n<div style=\"text-align: justify;\">Rather this is a list of things which you should act upon to make your own effective routine list.</div>\r\n<div style=\"text-align: justify;\">&nbsp;</div>\r\n<h3 style=\"text-align: justify;\"><span style=\"color: #e03e2d;\">1.1 - [[t1-s1]]Know Yourself[[/t1-s1]]:</span></h3>\r\n<div>&nbsp;</div>\r\n<div>\r\n<p style=\"text-align: justify;\">This quote of knowing yourself is something far more than an inspirational quote. It is a way of life. Coming from different fields like engineering, business or science, this one statement is applicable for everything.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">In the entrepreneurship world, the act of knowing yourself opens up tons of new opportunities. For knowing the right people, you need to know about yourself first. When you know your own unique personality, you will know which people to bond with.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">If you think your likes and dislikes play no role, think again. Psychology is an important aspect of strong networking. It connects the right kind of people together. Therefore, when you make connections with people, you are influenced by their perspectives.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">If you are someone who believes in optimism and approaches people who are honest, a dirty schemer will do you more harm than good. Similarly, when you know yourself, you won&rsquo;t just run after advantage. This will leave you injured in the long run. An important perspective of advantages is that you know your own shortcomings and personality. You will then know that it comes down to your attitude and effort. Both are not going to be harnessed when wrong people are in your company.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3 style=\"text-align: justify;\"><span style=\"color: #e03e2d;\">1.2 - [[t1-s2]]Know Them[[/t1-s2]]:</span></h3>\r\n<div>&nbsp;</div>\r\n<div>\r\n<p style=\"text-align: justify;\">What other thing is important. I explained this in the first step as well. The wrong people will seriously mess you up.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Suppose, you are looking for a person to assist you in the stock market. You ask around your resources. You are given reference to a very talented individual.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">You approach that person and form a deal. After some time as you start working with the individual, you realize his/her strategy is the exact opposite of what you want to do. In the end, the deal is over. You cannot work anymore with the same individual. You both suffer a loss.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">This is what is going to happen if you depend on people&rsquo;s opinions too much.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Get to know the individuals yourself. Check their interviews, posts, and emails. Get to know them instead of including them instantly. Just because a few people referred to a person, doesn&rsquo;t mean you can get your way with that person. Arrange meetings with them. Chat with their colleagues.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">When you are entering in dealing with an influencer, you should know that it is a long term relationship.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3 style=\"text-align: justify;\"><span style=\"color: #e03e2d;\">1.3 - [[t1-s3]]Show Up To Them[[/t1-s3]]:</span></h3>\r\n<div>&nbsp;</div>\r\n<div>\r\n<p style=\"text-align: justify;\">The influencers are often showing up on different channels. They are also present in different venues. You should make note of which places or channels they are going to show up next. Do some research on their types of venues. Find out their conferences, their events, and their speaking places.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Influencers are sharp people. You should try showing up more on their occasions. They will surely notice you. This will give the impression that you mean business.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\"><img title=\"influencer\" src=\"http://imran.unifyp.com/images/influencer.jpg\" alt=\"influencer\" width=\"100%\" /></p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3 style=\"text-align: justify;\"><span style=\"color: #e03e2d;\">1.4 - [[t1-s3]]Add Value To Your Demands[[/t1-s4]]:</span></h3>\r\n<div>&nbsp;</div>\r\n<div>\r\n<p style=\"text-align: justify;\">So let&rsquo;s suppose you find the kind of person you were looking for. The influencer deals with what you want.</p>\r\n<p style=\"text-align: justify;\">The next step should be to add value to your demands. Think about it. These influencers meet dozens of people like you every day. What makes them want you?</p>\r\n<p style=\"text-align: justify;\">Present something like this. Here is my requirement. Here is how it will benefit you. This will make them interested. Not only that, but the effective beneficial requirements will also help you stand out from the rest of the people they are seeing.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<h3 style=\"text-align: justify;\"><span style=\"color: #e03e2d;\">1.5 - [[t1-s3]]Moral Codes[[/t1-s5]]:</span></h3>\r\n<div>&nbsp;</div>\r\n<div>\r\n<p style=\"text-align: justify;\">There is something that makes moral codes an essential practice. Being a self-serving individual who is only in for own advantage makes for poor dealings. In the modern world of business, we are seeing lesser formalities and more human side.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">Being human and practicing moral codes will build slow but permanent foundations. You will make a name for yourself in the domain of influencers. The right kind of people will approach you.</p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\">The moral codes are also the basis of real relations. Putting a fa&ccedil;ade of something you are not will only harm you in the long run. You may meet a few dirty schemers who like to play people around. They get played around in the long run.</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>', 'http://ans-blog.unifyp.com/images/social-media-influencers.jpg', NULL, '1', 52, '2021-04-24 18:02:29', '2021-04-30 18:28:11');
INSERT INTO `posts` (`id`, `category_id`, `author_id`, `post_title`, `slug`, `meta_title`, `meta_description`, `meta_tags`, `post_schema`, `green_text`, `red_text`, `black_text`, `faqs`, `internal_tags`, `post_detail`, `post_cover_image`, `post_og_image`, `post_status`, `post_view`, `created_at`, `updated_at`) VALUES
(36, '8,9,10', 1, 'Eu iusto quis provid', 'dolorem-deserunt-sit', 'Vel velit enim reru', 'Velit eos non est au', 'Dolorem nihil debiti', '[\"Sed nisi atque ipsam\"]', '[[\"Eos dignissimos in n\",\"<p>teasljdfks<\\/p>\"],[\"Quo et consequatur\",null]]', '[[\"Culpa animi reicie\",null]]', '[[\"Sit ea ipsa provid\",null]]', '[[\"Ipsa enim culpa est\",null]]', NULL, '<p>lkfdk;alsdjf</p>\r\n<table class=\"table\">\r\n<tbody>\r\n<tr>\r\n<td>[[green:1]]</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>lsakdhkfksd</p>', 'http://ans-blog.unifyp.com/images/mother-son-embracing-outdoors-on-600w-746201944-370x259.webp', NULL, '1', 1, '2021-04-30 18:29:08', '2021-04-30 18:29:16');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) UNSIGNED NOT NULL,
  `google_analytic` text COLLATE utf8mb4_unicode_ci,
  `web_master` text COLLATE utf8mb4_unicode_ci,
  `bing_master` text COLLATE utf8mb4_unicode_ci,
  `menu` longtext COLLATE utf8mb4_unicode_ci,
  `logo_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `favicon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `robots` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `google_analytic`, `web_master`, `bing_master`, `menu`, `logo_image`, `favicon`, `og_image`, `smtp_email`, `smtp_password`, `robots`, `created_at`, `updated_at`) VALUES
(1, NULL, NULL, NULL, '[{\"link\":\"/\",\"title\":\"HOME\",\"type\":\"link\"},{\"link\":\"general-11\",\"title\":\"General\",\"type\":\"category\"},{\"link\":\"technology-18\",\"title\":\"Technology\",\"type\":\"category\"},{\"link\":\"bollywood-19\",\"title\":\"Bollywood\",\"type\":\"category\"},{\"link\":\"programming-110\",\"title\":\"Programming\",\"type\":\"category\"},{\"link\":\"contact-us\",\"title\":\"Contact US\",\"type\":\"link\"}]', 'http://ans-blog.unifyp.com/images/log-point.png', 'http://blog.dgp/images/favicon.png', 'http://ans-blog.unifyp.com/images/mother-son-embracing-outdoors-on-600w-746201944-370x259.webp', 'common@unifyp.com', 'eyJpdiI6IlZiaXlHMzUxdHFtMzFVdHdiZWNqSVE9PSIsInZhbHVlIjoiQ0t6MTNKSXEwZzdUVXZib2hIalA0RE5yOXhCMlZmT2krYVBiQ1l5M0VUND0iLCJtYWMiOiIwNjZlMGNlMTJmMjljYWMyYWNhZDA5MTI2NDJkMzg1MDRhOGIxMTA0OTViOWQ5NDZlNmI1MDMzZTk3NWQxNzM1In0=', NULL, NULL, '2021-04-30 18:24:30');

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subscribers`
--

INSERT INTO `subscribers` (`id`, `name`, `email`, `created_at`, `updated_at`) VALUES
(2, 'Anskhan', 'anskhilji900@gmail.com', '2021-03-20 02:00:00', '2021-03-20 12:40:50'),
(3, 'Asfand', 'kasfand@gmail.com', '2021-03-20 02:00:00', '2021-03-22 08:48:13'),
(8, 'Hadley Collier', 'kopel@mailinator.com', '2021-03-22 10:30:28', '2021-03-22 10:30:28'),
(9, 'Palmer Chan', 'tafamuzot@mailinator.com', '2021-03-22 10:39:07', '2021-03-22 10:39:07'),
(10, 'Selma Velazquez', 'vadeti@mailinator.com', '2021-03-22 10:40:00', '2021-03-22 10:40:00'),
(11, 'Jessica Vinson', 'fijikucyro@mailinator.com', '2021-03-22 10:41:04', '2021-03-22 10:41:04'),
(12, 'Danielle Snow', 'lukafybedy@mailinator.com', '2021-03-22 10:42:17', '2021-03-22 10:42:17'),
(13, 'Joel Dillard', 'wyge@mailinator.com', '2021-03-22 10:43:09', '2021-03-22 10:43:09'),
(14, 'Libby Rivera', 'filikyf@mailinator.com', '2021-03-22 10:43:44', '2021-03-22 10:43:44'),
(15, 'Allegra Flowers', 'kafoj@mailinator.com', '2021-03-22 10:44:19', '2021-03-22 10:44:19'),
(16, 'Sybil David', 'xeza@mailinator.com', '2021-03-22 10:49:40', '2021-03-22 10:49:40'),
(17, 'noman', 'nomi@gmail.com', '2021-03-22 10:50:06', '2021-03-22 10:50:06'),
(20, 'Deborah Haney', 'bepigoz@mailinator.com', '2021-03-22 10:54:53', '2021-03-22 10:54:53'),
(21, 'khalid', 'khan@gmial.com', '2021-03-25 08:34:33', '2021-03-25 08:34:33'),
(22, 'ansh', 'test@gmail.com', '2021-03-31 12:01:21', '2021-03-31 12:01:21'),
(23, 'udced', 'udced@gmail.com', '2021-04-27 14:45:31', '2021-04-27 14:45:31');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `slug`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'eyJpdiI6IkdrT1R1dkFucGk3bVRTcEd5QVBVMnc9PSIsInZhbHVlIjoiT0trSE80RVJjb3JxdE55S2RLUUJPZz09IiwibWFjIjoiMmE5ZDJjZjc5Y2E5NjBiNjQ0N2FjMjNmOTUxZWUzM2JlMTE3MDJhN2M3MjZlNzIyYTc3ZTI2ZTE3YmRmMTJhZSJ9', 'eyJpdiI6IkZ3VDBHSU8wQUZGRXF4N05vLzJid2c9PSIsInZhbHVlIjoiTmJRcE5oQnlycGdPbk5KM3QzTUdXaWxNR0FsNmVOK05va2cwbmJTTTUwaz0iLCJtYWMiOiI4NDA4Njk2MWIzNjZhZjc3NTg4Zjk4OWRkNGI5NjVhZmRjMTQ2YTk3MWIyYTljODNlNjc2NTQzMWQ0ODg4YWIyIn0=', '2021-03-04 02:00:00', '$2y$10$mw5lFnbeQ1DFUdjTXthayeVuLkEDEET9Uqj8vQxMkydn9uGeK5Sra', 'eyJpdiI6Iml2b2NrUDVxNTZib2Z5ZGRjVk9mVXc9PSIsInZhbHVlIjoiU2tYdWN1ci9GUnFEMXp1bmgvbFBTUT09IiwibWFjIjoiZGIyYTBjYjIzNjAyNzdmZmU5MDgxZjk0NTY2YWExYTU0N2YzYWIyYTExMDkzMTQwMDczOGU3NmJiOWM3MmVmYyJ9', 'ktDZk8edKMSoMEUlmtLMNJXqdpenZJ2em43RcBCSxZHOjRMa5Ja7cGpeDGHP', '2021-03-04 02:00:00', '2021-04-30 19:03:26');

-- --------------------------------------------------------

--
-- Table structure for table `visits`
--

CREATE TABLE `visits` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `views` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `visits`
--

INSERT INTO `visits` (`id`, `views`, `date`) VALUES
(1, 3, '2021-01-15'),
(2, 216, '2021-01-16'),
(3, 53, '2021-01-17'),
(4, 58, '2021-01-18'),
(5, 1, '2021-01-19'),
(6, 19, '2021-01-20'),
(7, 54, '2021-01-22'),
(8, 90, '2021-01-23'),
(9, 156, '2021-01-25'),
(10, 84, '2021-01-26'),
(11, 1, '2021-01-26'),
(12, 29, '2021-01-27'),
(13, 2, '2021-01-28'),
(14, 45, '2021-01-29'),
(15, 32, '2021-01-31'),
(16, 55, '2021-02-01'),
(17, 2, '2021-02-08'),
(18, 45, '2021-02-16'),
(19, 14, '2021-02-19'),
(20, 15, '2021-02-24'),
(21, 3, '2021-03-04'),
(22, 2, '2021-03-11'),
(23, 1, '2021-03-31'),
(24, 2, '2021-04-01'),
(25, 307, '2021-04-02'),
(26, 132, '2021-04-03'),
(27, 65, '2021-04-05'),
(28, 30, '2021-04-06'),
(29, 104, '2021-04-07'),
(30, 5, '2021-04-08'),
(31, 12, '2021-04-09'),
(32, 62, '2021-04-16'),
(33, 25, '2021-04-17'),
(34, 82, '2021-04-19'),
(35, 29, '2021-04-20'),
(36, 45, '2021-04-21'),
(37, 119, '2021-04-22'),
(38, 87, '2021-04-24'),
(39, 249, '2021-04-26'),
(40, 331, '2021-04-27'),
(41, 79, '2021-04-28'),
(42, 6, '2021-04-29'),
(43, 11, '2021-04-30'),
(44, 4, '2021-05-03'),
(45, 1, '2021-05-10'),
(46, 4, '2021-05-11'),
(47, 1, '2021-05-16'),
(48, 1, '2021-05-18'),
(49, 2, '2021-05-27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `homes`
--
ALTER TABLE `homes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `internallinks`
--
ALTER TABLE `internallinks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `media_category`
--
ALTER TABLE `media_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `media_setting`
--
ALTER TABLE `media_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `visits`
--
ALTER TABLE `visits`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `authors`
--
ALTER TABLE `authors`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `homes`
--
ALTER TABLE `homes`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `internallinks`
--
ALTER TABLE `internallinks`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `media_category`
--
ALTER TABLE `media_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `media_setting`
--
ALTER TABLE `media_setting`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `visits`
--
ALTER TABLE `visits`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
